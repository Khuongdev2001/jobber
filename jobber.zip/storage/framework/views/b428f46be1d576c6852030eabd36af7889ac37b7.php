
<?php $__env->startSection("title","trang chủ bài viết"); ?>
<?php $__env->startSection("css"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("js"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<div class="post-index">
    <div class="container-xl">
        <div class="row">
            <div class="box-left col-md-8 box-type-post">
                <div class="post-new">
                    <div class="box-search-post">
                        <h4 class="title">
                            <?php if(request("search")): ?>
                            <span class="keyword"><?php echo e(request("search")); ?></span>
                            -
                            <?php endif; ?>
                            kết quả tìm kiếm
                        </h4>
                        <form action="" class="box-search position-relative">
                            <div class="form-group">
                                <input type="text" class="form-control" name="search" value="<?php echo e(request("search")); ?>" class="search">
                                <button class="btn-search">tìm kiếm</button>
                            </div>
                        </form>
                        <span class="lable">
                            Vui lòng tìm lại nếu chưa hài lòng
                        </span>
                    </div>
                    <ul class="box-list-post">
                        <?php $__currentLoopData = $posts; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-post">
                            <div class="row">
                                <a href="<?php echo e(route("post.info",$post->Post_Slug)); ?>" class="box-thumbnail col-4">
                                    <img class="thumbnail" src="<?php echo e(asset($post->Thumbnail)); ?>" alt="<?php echo e($post->Post_Title); ?>">
                                </a>
                                <div class="info col-8">
                                    <h5 class="title">
                                        <a href="<?php echo e(route("post.info",$post->Post_Slug)); ?>">
                                            <?php echo e(Str::limit($post->Post_Title,40)); ?>

                                        </a>
                                    </h5>
                                    <span class="date-create">
                                        <?php echo e(date("Y-m-d",$post->Post_Created_At)); ?>

                                    </span>
                                    <p class="desc">
                                        <?php echo e(Str::limit($post->Post_Description,80)); ?>

                                    </p>
                                </div>
                            </div>    
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                        
                    </ul>
                    <div class="box-option text-center">
                        <?php echo e($posts->appends(["search"=>request("search")])->links()); ?>

                    </div>
                </div>
                <div class="advertisement pb-3">
                    <a href="" class="box-thumbnail"><img src="https://blog.topcv.vn/wp-content/uploads/2021/02/NTMN-KINHTE-TOPCV-BANNER.jpg" class="thumbnail" alt=""></a>
                </div>
            </div>
            <div class="box-right col-md-4">
                <div class="advertisement">
                    <a href="" class="box-thumbnail">
                        <img class="thumbnail" src="https://blog.topcv.vn/wp-content/uploads/2020/02/Banner-blog-topcv-001.jpg" alt="">
                    </a>
                </div>
                <div class="advertisement p-3">
                    <a href="" class="box-thumbnail">
                        <img class="thumbnail" src="https://blog.topcv.vn/wp-content/uploads/2020/11/Job-TopCV-1080x1080px.jpg" alt="">
                    </a>
                </div>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("candidate.master.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\project_cv\jobber\resources\views/candidate/post/index.blade.php ENDPATH**/ ?>