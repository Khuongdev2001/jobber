<?php

namespace App\Http\Requests\candidate\user;

use Illuminate\Foundation\Http\FormRequest;

class RegRequest extends FormRequest
{
    /**
     * Determine if the user is authorized to make this request.
     *
     * @return bool
     */
    public function authorize()
    {
        return true;
    }

    /**
     * Get the validation rules that apply to the request.
     *
     * @return array
     */
    public function rules()
    {
        return [
            "Fullname" => "required|max:50",
            "User_Email" => "required|email|unique:users|max:50",
            "User_Password" => "required|max:50",
            "Re_User_Password" => "required|same:User_Password",
        ];
    }

    public function messages()
    {
        return
            [
                "Fullname.required" => "Họ tên không được để trống",
                "User_Email.required" => "Email không được bỏ trống",
                "User_Email.email" => "Không phải định dạng Email",
                "User_Email.unique" => "Email đã đăng ký hệ thống",
                "User_Password.required" => "Mật khẩu không được bỏ trống",
                "Re_User_Password.same" => "Mật khẩu xác thực không khớp",
            ];
    }
}
