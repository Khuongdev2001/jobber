
<?php $__env->startSection("title","Danh sách công việc đã lưu"); ?>
<?php $__env->startSection("css"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("js"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<div class="container">
    <nav aria-label="breadcrumb">
        <ol class="breadcrumb">
            <li class="breadcrumb-item"><a href="<?php echo e(route("home")); ?>">Trang chủ</a></li>
            <li class="breadcrumb-item"><a href="#">Tìm kiếm việc làm</a></li>
        </ol>
    </nav>
    <div id="box-result" class="bg-white text-muted">
        <div class="row">
            <div class="col-md-7">
                <h4 class="title">Tìm việc làm mới nhất</h4>
            </div>
            <div class="col-md-3 col-6">
                <strong class="num-job-finded"><?php echo e($jobs->total()); ?></strong> Việc làm phù hợp
            </div>
            
        </div>
    </div>
    <div id="featured" class="row jobs-seached">
        <div class="col-md-8 box-job-finded">
            <?php $__currentLoopData = $jobs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $job): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
            <div class="job-featured">
                <div class="icon">
                    <img src="<?php echo e(asset($job->Company_Logo)); ?>" alt="<?php echo e($job->Job_Title); ?>">
                </div>
                <div class="content">
                    <h3><a href="<?php echo e(route("job.info",$job->Job_Slug)); ?>"><?php echo e(Str::limit($job->Job_Title,40)); ?></a></h3>
                    <a href="<?php echo e(route("jobSave.option",$job->Job_ID)); ?>" class="btn-save-job"><i class="far fa-heart"></i></a>
                    <p class="brand"><?php echo e($job->Company_Name); ?></p>
                    <div class="tags">
                        <span><i class="lni-map-marker"></i><?php echo e($job->Province_Name); ?></span>
                        <?php
                            $wage="Thỏa thuận";
                            if($job->Wage_From || $job->Wage_To){
                                $wage=$job->Wage_From ? "Từ".currency($job->Wage_From) : " Đến ".currency($job->Wage_To);
                            }
                            if($job->Wage_From && $job->Wage_To){
                                $wage="Từ ".currency($job->Wage_From)." Đến ".currency($job->Wage_To); 
                            }
                        ?>
                        <span><i class="far fa-money-bill-alt"></i><?php echo e($wage); ?></span>
                        <span><i class="far fa-clock"></i></i><?php echo e(date("Y-m-d",$job->Job_Created_At)); ?></span>
                    </div>
                </div>
            </div>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            <?php echo e($jobs->appends(["Job_Title"=>request("Job_Title"),"Specialize_ID"=>request("Specialize_ID"),"Province_ID"=>request("Province_ID"),"Experience"=>request("Experience"),"Job_Type"=>request("Job_Type")])->links()); ?>

        </div>
        <div id="advertisement-company-light" class="col-md-4 position-sticky py-2">
            <div class="box-advertisement">
                <a href="" class="box-thumbnail"><img src="https://static.topcv.vn/img/Banner%20Right%20FE%20Credit%20MT.jpg" class="company-banner" alt=""></a>
            </div>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("candidate.master.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\project_cv\jobber\resources\views/candidate/job/index.blade.php ENDPATH**/ ?>