
<?php $__env->startSection("title","Xin chào công ty {$employer->Company_Name}"); ?>
<?php $__env->startSection("css"); ?>
    
    <link rel="stylesheet" href="<?php echo e(asset("employer/plugins/dropimage/css/main.css")); ?>">
    <link href="https://unpkg.com/cropperjs/dist/cropper.css" rel="stylesheet" />
    
    <link rel="stylesheet" href="<?php echo e(asset("admin/plugins/select2/css/select2.min.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("admin/plugins/select2/css/select2-bootstrap4.css")); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection("js"); ?>
    <script src="https://unpkg.com/dropzone"></script>
    <script src="https://unpkg.com/cropperjs"></script>
    <script src="<?php echo e(asset("employer/plugins/dropimage/js/main.js")); ?>"></script>
    
    <script src="<?php echo e(asset("admin/plugins/select2/js/select2.min.js")); ?>"></script>
    <script>
        $('#Specialize_ID').select2({
        minimumInputLength: 2,
        ajax: {
            url: '<?php echo e(route("employer.data.specialize")); ?>',
            type: 'GET',
            dataType: 'json',
            data: function (params) {
                return {Name: params.term};
            },
            processResults: function (data, params) {
                return {results: $.map(data, function (item) {return {text: item.Name,id: item.Specialize_ID,data: item};})
                };
            }}
        });

        $('#Province_ID').select2({
        minimumInputLength: 2,
        ajax: {
            url: '<?php echo e(route("employer.data.province")); ?>',
            type: 'GET',
            dataType: 'json',
            data: function (params) {
                return {Province_Name: params.term};
            },
            processResults: function (data, params) {
                return {results: $.map(data, function (item) {return {text: item.Province_Name,id: item.Province_ID,data: item};})
                };
            }
        }
    });
    
    $(".btn-upload-logo").click(function(){
        $("#upload-file-logo").trigger("click");
    })
    $(".btn-upload-cover").click(function(){
        $("#upload-file-cover").trigger("click");
    })
	crop_image({
		id_preview: "preview_logo",
		model_preview: "#modal-upload-logo",
		btn_drop: "#crop_logo",
		producted: ".box-preview-logo .box-thumbnail .thumbnail",
		preview_mini: "#modal-upload-logo .preview_logo_mini",
		input: "#upload-file-logo",
        hidden_file:".box-preview-logo .hidden-file"
	});

    crop_image({
		id_preview: "preview_cover",
		model_preview: "#modal-upload-cover",
		btn_drop: "#crop_cover",
		producted: ".box-preview-cover .box-thumbnail .thumbnail",
		preview_mini: "#modal-upload-cover .preview_cover_mini",
		input: "#upload-file-cover",
        hidden_file:".box-preview-cover .hidden-file",
        ratio:2.1
	});
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("header"); ?>
    <?php echo $__env->make("employer.include.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="container">
    <div class="row">
        <div class="box-profile-company col-md-8">
            <h2 class="title text-center">Thông tin chi tiết</h2>
            <nav class="box-top-controll">
                <ul class="box-option list-unstyled d-flex">
                    <li>
                        <a href="<?php echo e(route("employer.info")); ?>" class="" id="label-info-employer">Nhà tuyển dụng</a>
                    </li>
                    <li>
                        <a href="javascript:void(0)" class="active" id="label-info-company">Công ty</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route("employer.history")); ?>" class="" id="label-history">Lịch sử hoạt động</a>
                    </li>
                </ul>
            </nav>
            <div class="box-info">
                <ul class="list-info list-unstyled">
                    <form action="<?php echo e(route("employer.company.update")); ?>" method="post" class="row">
                        <?php echo csrf_field(); ?>
                        <!-- company name -->
                        <div class="form-group <?php $__errorArgs = ["Company_Name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> col-md-6">
                            <label for="Company_Name">Tên công ty: </label>
                            <input type="text" id="Company_Name" name="Company_Name" class="form-control" value="<?php echo e(old("Company_Name") ?? $employer->Company_Name); ?>">
                            <?php $__errorArgs = ["Company_Name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                              <span class="message"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!-- end company name -->

                        <!-- company phone -->
                        <div class="form-group col-md-6 <?php $__errorArgs = ["Company_Phone"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label for="Company_Phone">Số điện thoại công ty: </label>
                            <input type="text" id="Company_Phone" name="Company_Phone" class="form-control" value="<?php echo e(old("Company_Phone") ?? $employer->Company_Phone); ?>">
                            <?php $__errorArgs = ["Company_Phone"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="message"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!-- end company phone -->

                        <!-- company address -->
                        <div class="form-group col-md-6 <?php $__errorArgs = ["Company_Address"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label for="Company_Address">Địa chỉ công ty: </label>
                            <input type="text" id="Company_Address" name="Company_Address" class="form-control" value="<?php echo e(old("Company_Address") ?? $employer->Company_Address); ?>">
                            <?php $__errorArgs = ["Company_Address"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="message"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!-- end company phone -->

                        <!-- company size -->
                        <div class="form-group col-md-6 <?php $__errorArgs = ["Company_Size"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> ">
                            <label for="Company_Size">Quy mô công ty: </label>
                            <select name="Company_Size" id="Company_Size" class="form-control">
                               <?php $__currentLoopData = __("user.Company_Size"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                  <option value="<?php echo e($key); ?>" <?php if($employer->Company_Size && $employer->Company_Size == $key ): ?> selected  <?php endif; ?>><?php echo e($item); ?></option>
                               <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                            <?php $__errorArgs = ["Company_Size"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="message"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!-- end company size -->

                        <!-- company speciality -->
                        <div class="form-group col-md-6 <?php $__errorArgs = ["Specialize_ID"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label for="Specialize_ID">Nghành nghề kinh doanh: </label>
                            <select type="text" id="Specialize_ID" name="Specialize_ID" class="form-control">
                                <option value="<?php echo e($employer->specialize->Specialize_ID); ?>"><?php echo e($employer->specialize->Name); ?></option>
                            </select>
                            <?php $__errorArgs = ["Specialize_ID"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="message"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!-- end company speciality -->

                        <!-- company province -->
                        <div class="form-group col-md-6 <?php $__errorArgs = ["Province_ID"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label for="Province_ID">Tỉnh thành: </label>
                            <select type="text" id="Province_ID" name="Province_ID" class="form-control">
                                <option value="<?php echo e($employer->province->Province_ID ?? ""); ?>"><?php echo e($employer->province->Province_Name ?? ""); ?></option>
                            </select>
                            <?php $__errorArgs = ["Province_ID"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="message"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!-- end company province -->

                        <!-- company contactor -->
                        <div class="form-group col-md-6 <?php $__errorArgs = ["Company_Contactor"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label for="Company_Contactor">Người liên hệ: </label>
                            <input type="text" id="Company_Contactor" name="Company_Contactor" class="form-control" value="<?php echo e(old("Company_Contactor") ?? $employer->Company_Contactor); ?>">
                            <?php $__errorArgs = ["Company_Contactor"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="message"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!-- end company contactor -->

                        <!-- company email -->
                        <div class="form-group col-md-6 <?php $__errorArgs = ["Company_Email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label for="Company_Email">Email công ty: </label>
                            <input type="text" id="Company_Email" name="Company_Email" class="form-control" value="<?php echo e(old("Company_Email") ?? $employer->Company_Email); ?>">
                            <?php $__errorArgs = ["Company_Email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="message"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!-- end company email -->

                        <!-- company website -->
                        <div class="form-group col-md-6 <?php $__errorArgs = ["Company_Website"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                            <label for="Company_Website">Website công ty: </label>
                            <input type="text" id="Company_Website" name="Company_Website" class="form-control" value="<?php echo e(old("Company_Website") ?? $employer->Company_Website); ?>">
                            <?php $__errorArgs = ["Company_Website"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                                <span class="message"><?php echo e($message); ?></span>
                            <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!-- end company websit -->

                        <!-- company desc -->
                        <div class="form-group col-md-12">
                            <label for="Company_Description">Mô tả công ty: </label>
                            <textarea name="Company_Description" id="Company_Description" class="form-control" cols="30" rows="6"><?php echo e(old("Company_Description") ?? $employer->Company_Description); ?></textarea>
                            <?php $__errorArgs = ["Company_Website"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="message"><?php echo e($message); ?></span>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                        </div>
                        <!-- end company desc -->

                        <!-- company-avatar -->
                        <div class="form-group col-12">
                            <label for="company-logo">Logo công ty:<small>(Sẽ hiện thị mỗi bài đăng)</small></label>
                            <div class="box-preview-logo text-center">
                                <a href="javascript:void(0)" class="box-thumbnail">
                                    <?php
                                        $url="";
                                        if($employer->Company_Logo){
                                            $url=asset($employer->Company_Logo);
                                        }
                                    ?>
                                    <img class="thumbnail img-fluid" src="<?php echo e($url); ?>">
                                </a>
                                <input type="file" name="company-logo" id="upload-file-logo" class="d-none">
                                <input type="hidden" class="hidden-file" name="Company_Logo">
                                <a href="javascript:void(0)" class="btn btn-upload btn-upload-logo"><i class="fas fa-cloud-upload-alt"></i></a>
                            </div>
                        </div>
                        <!-- end company-logo  -->

                        <!-- company-cover -->
                        <div class="form-group col-12">
                            <label for="company-cover">Banner công ty:</label>
                            <div class="box-preview-cover">
                                <a href="javascript:void(0)" class="box-thumbnail">
                                    <?php
                                        $url="";
                                        if($employer->Company_Cover){
                                            $url=asset($employer->Company_Cover);
                                        }
                                    ?>
                                    <img class="thumbnail img-fluid" src="<?php echo e($url); ?>">
                                </a>
                                <input type="file" name="company-cover" id="upload-file-cover" class="d-none">
                                <a href="javascript:void(0)" class="btn btn-upload btn-upload-cover"><i class="fas fa-cloud-upload-alt"></i></a>
                                <input type="hidden" class="hidden-file" name="Company_Cover">
                            </div>
                        </div>
                        <!-- end company-cover -->
                        <!-- btn -->
                        <div class="form-group col-12">
                            <button class="btn btn-outline-success float-right">Cập nhật</button>
                        </div>
                        <!-- end btn -->
                    </form>
                </ul>
            </div>
        </div>
        <div class="col-md-4 pt-5">
            <a href=""><img class="img-fluid" src="https://www.aviva.com.vn/Data/Sites/1/media/aviva-vietnam_photo.jpg" alt=""></a>
        </div>
    </div>
</div>

<!-- modal upload logo -->
<div class="modal fade" id="modal-upload-logo" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Chỉnh sửa logo</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="img-container">
                    <div class="row">
                        <div class="col-md-8">
                            <img src="" id="preview_logo" />
                        </div>
                        <div class="col-md-4">
                            <div class="preview_logo_mini"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" id="crop_logo" class="btn btn-primary">Lưu</button>
            </div>
        </div>
    </div>
</div>
<!-- end modal -->

<!-- modal upload cover -->
<div class="modal fade" id="modal-upload-cover" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Chỉnh sửa logo</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="img-container">
                    <div class="row">
                        <div class="col-md-8">
                            <img src="" id="preview_cover" />
                        </div>
                        <div class="col-md-4">
                            <div class="preview_cover_mini"></div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" id="crop_cover" class="btn btn-primary">Lưu</button>
            </div>
        </div>
    </div>
</div>
<!-- end modal -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make("employer.master.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\project_cv\jobber\resources\views/employer/company/info.blade.php ENDPATH**/ ?>