
<?php $__env->startSection("title","trang chủ bài viết"); ?>
<?php $__env->startSection("css"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("js"); ?>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<div class="post-index">
    <div class="container-xl">
        <div class="row">
            <div class="box-left col-md-8 box-type-post">
                <div class="advertisement">
                    <a href="" class="box-thumbnail"><img src="https://blog.topcv.vn/wp-content/uploads/2021/02/NTMN-KINHTE-TOPCV-BANNER.jpg" class="thumbnail" alt=""></a>
                </div>
                    <div class="post-hight-light">
                        <h4 class="title">Bài viết nổi bậc</h4>
                        <ul class="box-list-post row">
                            <?php $__currentLoopData = $postHighLights; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-post col-md-6">
                                <div class="row">
                                    <a href="<?php echo e(route("post.info",$post->Post_Slug)); ?>" class="box-thumbnail col-4">
                                        <img src="<?php echo e(asset($post->Thumbnail)); ?>" alt="<?php echo e($post->Post_Title); ?>" class="thumbnail">
                                    </a>
                                    <div class="info col-8">
                                        <h5 class="title"> <a href="<?php echo e(route("post.info",$post->Post_Slug)); ?>"><?php echo e(Str::limit($post->Post_Title,60)); ?></a></h5>
                                        <span class="date-created">
                                            <?php echo e(date("Y-m-d",$post->Post_Created_At)); ?>

                                        </span>
                                    </div>
                                </div>
                            </li>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </ul>
                        <div class="box-option text-center pt-3">
                            <a href="<?php echo e(route("post",["hightlight"=>1])); ?>" class="btn-css-other">Xem thêm</a>
                        </div>
                    </div>
                    <div class="post-set-cat">
                        <h5 class="title">
                            Sức Khỏe/Đời Sống
                        </h5>
                        <ul class="box-list-post row">
                            <?php $__currentLoopData = $postCats; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <li class="list-post col-md-6">
                                <a href="<?php echo e(route("post.info",$post->Post_Slug)); ?>" class="box-thumbnail">
                                    <img src="<?php echo e(asset($post->Thumbnail)); ?>" style="width: 200px" alt="<?php echo e($post->Post_Title); ?>" class="thumbnail">
                                </a>
                                <div class="info">
                                    <span class="date-create"><?php echo e(date("Y-m-d",$post->Post_Created_At)); ?></span>
                                    <p class="desc"><?php echo e(Str::limit($post->Post_Description,80)); ?></p>
                                </div>
                            </li>               
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>             
                        </ul>
                        <div class="box-option text-center">
                            <a href="<?php echo e(route("post",["cat"=>14])); ?>" class="btn-css-border-other">Xem thêm</a>
                        </div>
                    </div>
                <div class="post-new">
                    <h5 class="title">
                        Bài viết mới nhất
                    </h5>
                    <ul class="box-list-post">
                        <?php $__currentLoopData = $postNews; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $post): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="list-post">
                            <div class="row">
                                <a href="<?php echo e(route("post.info",$post->Post_Slug)); ?>" class="box-thumbnail col-4"><img class="thumbnail" src="<?php echo e(asset($post->Thumbnail)); ?>" alt="<?php echo e($post->Post_Title); ?>"></a>
                                <div class="info col-8">
                                    <h5 class="title">
                                        <a href="<?php echo e(route("post.info",$post->Post_Slug)); ?>">
                                            <?php echo e($post->Post_Title); ?>

                                        </a>
                                    </h5>
                                    <span class="date-create">
                                        <?php echo e(date("Y-m-d",$post->Post_Created_At)); ?>

                                    </span>
                                    <p class="desc">
                                        <?php echo e(Str::limit($post->Post_Description,80)); ?>

                                    </p>
                                </div>
                            </div>    
                        </li>  
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                      
                    </ul>
                    <div class="box-option text-center">
                        <a href="<?php echo e(route("post",["new"=>1])); ?>" class="btn-css-other">Xem thêm</a>
                    </div>
                </div>
            </div>
            <div class="box-right col-md-4">
                <div class="advertisement">
                    <a href="" class="box-thumbnail">
                        <img class="thumbnail" src="https://blog.topcv.vn/wp-content/uploads/2020/02/Banner-blog-topcv-001.jpg" alt="">
                    </a>
                </div>
                <div class="advertisement p-3">
                    <a href="" class="box-thumbnail">
                        <img class="thumbnail" src="https://blog.topcv.vn/wp-content/uploads/2020/11/Job-TopCV-1080x1080px.jpg" alt="">
                    </a>
                </div>
            </div>
        </div>

    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("candidate.master.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\project_cv\jobber\resources\views/candidate/post/home.blade.php ENDPATH**/ ?>