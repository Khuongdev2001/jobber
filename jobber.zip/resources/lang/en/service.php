<?php

return [
    "admin" => [
        '<a href="javascript:void(0)" data-url=":accept" class="btn-hero btn-success-hero btn-accept"><i class="far fa-check-circle"></i></a>
        <a href="javascript:void(0)" data-url=":deny" class="btn-hero btn-danger-hero btn-deny shadow"><i class="fas fa-times"></i></a>',
        '<a href="javascript:void(0)" class="btn-hero btn-success-hero"">Đã xác nhận</a>',
        '<a href="javascript:void(0)" class="btn-hero btn-danger-hero shadow">Đã từ chối</a>',
    ]
];
