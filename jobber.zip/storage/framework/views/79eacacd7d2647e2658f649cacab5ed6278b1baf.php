
<?php $__env->startSection('title', 'Danh sách nhà tuyển dụng'); ?>
<?php $__env->startSection('css'); ?>
    
   <?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
   
<?php $__env->stopSection(); ?>



<?php $__env->startSection('sidebar'); ?>
##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!--start page wrapper -->
    <div class="page-wrapper">
        <div class="page-content">
            <!--breadcrumb-->
            <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
                <div class="breadcrumb-title pe-3">Cấu hình</div>
                <div class="ps-3">
                    <nav aria-label="breadcrumb">
                        <ol class="breadcrumb mb-0 p-0">
                            <li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
                            </li>
                            <li class="breadcrumb-item active" aria-current="page">Cập nhật giá gói cước</li>
                        </ol>
                    </nav>
                </div>
                <div class="ms-auto">
                </div>
            </div>
            <!--end breadcrumb-->
            <div class="container">
                <div class="main-body" style="min-height: 500px;">
                    <form action="<?php echo e(route("admin.package.post.update")); ?>" method="post" class="py-3 form-update-package bg-white text-dark p-2">
                        <h6 class="title text-dark">Gói đăng tin</h6>
                        <div class="row">
                            <?php echo csrf_field(); ?>
                            <input type="hidden" name="continue" value="<?php echo e(route("admin.package.config")); ?>">
                            <?php $__currentLoopData = $postPackages; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $package): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <div class="form-group col-md-4 my-2">
                                <label for=""><?php echo e($package->Package_Name); ?></label>
                                <input type="hidden" name="Package_ID[]" value="<?php echo e($package->Package_ID); ?>">
                                <input type="text" class="form-control" name="Package_Value[<?php echo e($package->Package_ID); ?>]" value="<?php echo e($package->Package_Price); ?>">
                            </div>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            <div class="col-12">
                                <button class="btn-hero btn-success-hero">Cập nhật</button>
                            </div>
                        </div>
                    </form>
   
                    <form action="<?php echo e(route("admin.package.fitlter.update")); ?>" method="POST" class="py-3 form-update-package">
                        <h6 class="title">Gói lọc hồ sơ: </h6>
                        <?php echo csrf_field(); ?>
                        <input type="hidden" name="continue" value="<?php echo e(route("admin.package.config")); ?>">
                        <div class="row" style="align-items: flex-end" >
                            <div class="form-group col-md-4">
                                <label for="">Số tiền: </label>
                                <div class="d-flex">
                                    <input type="text" name="Package_Price" class="form-control" value="<?php echo e($fitlerPackage->Package_Price); ?>" id="">
                                </div>
                            </div>
                            <div class="form-group col-md-4">
                                <label for="">Số điểm: </label>
                                <div class="d-flex">
                                    <input type="text" name="Package_Value" class="form-control" value="<?php echo e($fitlerPackage->Package_Value); ?>" id="">
                                </div>
                            </div>
                            <div class="col-4">
                                <button class="btn-hero btn-success-hero">Cập nhật</button>
                            </div>
                        </div>
                    </form>
                </div>
            </div>
        </div>
    </div>
<!--end page wrapper -->

<div id="add-cat" class="modal-more">
    <div class="modal-notification modal-lg text-dark">
        <button class="btn-exit btn"><i class="fas fa-times-circle"></i></button>
    </div>
    <div class="dialog"></div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?><?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.master.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\project_cv\jobber\resources\views/admin/package/config.blade.php ENDPATH**/ ?>