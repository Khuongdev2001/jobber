
<?php $__env->startSection("title","Lịch sử hoạt động của bạn"); ?>
<?php $__env->startSection("css"); ?>
    
    <link rel="stylesheet" href="<?php echo e(asset("employer/plugins/dropimage/css/main.css")); ?>">
    <link href="https://unpkg.com/cropperjs/dist/cropper.css" rel="stylesheet" />
    
    <link rel="stylesheet" href="<?php echo e(asset("admin/plugins/select2/css/select2.min.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("admin/plugins/select2/css/select2-bootstrap4.css")); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection("js"); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("header"); ?>
    <?php echo $__env->make("employer.include.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="container">
        <div class="box-profile-employer">
            <h2 class="title text-center">Thông tin chi tiết</h2>
            <nav class="box-top-controll">
                <ul class="box-option list-unstyled d-flex">
                    <li>
                        <a href="<?php echo e(route("employer.info")); ?>" id="label-info-employer">Nhà tuyển dụng</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route("employer.company.info")); ?>" class="" id="label-info-company">Công ty</a>
                    </li>
                    <li>
                        <a href="javascript:void(0)" class="active" id="label-history">Lịch sử hoạt động</a>
                    </li>
                </ul>
            </nav>
            <form action="" class="input-group" method="GET">
                <input type="text" name="search" class="form-control" value="<?php echo e(request("search")); ?>"  id="">
                <div class="input-group-prepend">
                    <button class="btn btn-success">Tìm Kiếm</button>
                 </div>
            </form>
            <table class="table table-bordered">
                <tr class="text-center">
                    <th>STT</th>
                    <th>Nội Dung</th>
                    <th>Ngày</th>
                </tr>   
                <?php
                    $temp=0;
                ?>
                <?php $__currentLoopData = $historys; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $history): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>             
                    <tr>
                        <td><?php echo e($temp++); ?></td>
                        <td><?php echo e($history->History_Content); ?></td>
                        <td><?php echo e($history->History_Created_At); ?></td>
                    </tr>      
                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                  
            </table>            
            <?php echo e($historys->appends(["search"=>request("search")])->links()); ?>

        </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("employer.master.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\project_cv\jobber\resources\views/employer/history/index.blade.php ENDPATH**/ ?>