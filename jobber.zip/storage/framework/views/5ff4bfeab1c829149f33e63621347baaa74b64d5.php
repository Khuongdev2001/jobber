<header id="home" class="hero-area">
   <?php if(empty($setMenuPost)): ?> 
    <nav class="navbar navbar-expand-lg fixed-top scrolling-navbar">
        <div class="container">
            <div class="theme-header clearfix">
                <div class="navbar-header">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-navbar" aria-controls="main-navbar" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                        <span class="lni-menu"></span>
                        <span class="lni-menu"></span>
                        <span class="lni-menu"></span>
                    </button>
                    <a href="<?php echo e(route("home")); ?>" class="navbar-brand"><img src="<?php echo e(asset("candidate/imgs/logo.png")); ?>" alt="jobber"></a>
                </div>
                <div class="collapse navbar-collapse" id="main-navbar">
                    <ul class="navbar-nav mr-auto w-100 justify-content-end">
                        <li class="nav-item dropdown <?php echo e(setMenuActive("home","candidate")); ?>">
                            <a class="nav-link dropdown-toggle" href="<?php echo e(route("home")); ?>">
                                Trang chủ
                            </a>
                        </li>
                        <li class="nav-item <?php echo e(setMenuActive("job","candidate")); ?>">
                            <a class="nav-link dropdown-toggle" href="<?php echo e(route("job")); ?>">
                                Việc làm
                            </a>
                        </li> 
                        <li class="nav-item <?php echo e(setMenuActive("company","candidate")); ?>">
                            <a class="nav-link dropdown-toggle" href="<?php echo e(route("company")); ?>">
                                Công ty
                            </a>
                        </li>
                        <li class="nav-item dropdown">
                            <a href="<?php echo e(route("post.home")); ?>" class="nav-link dropdown-toggle">
                                Cẩm nang
                            </a>
                        </li>
                        
                        <?php if(session("candidate")): ?>
                        <li class="nav-item dropdown">
                            <a class="nav-link dropdown-toggle d-inline-block" style="width: 75px" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                                <?php                                    
                                    $url=session("candidate.Avatar") ?? "candidate/imgs/company/default.webp";                                   
                                ?>
                                <img class="thumbnail rounded-circle" src="<?php echo e(asset($url)); ?>" alt="">
                            </a>
                            <ul class="dropdown-menu">
                                <li><a class="dropdown-item" href="<?php echo e(route("info")); ?>"><?php echo e(session("candidate.Fullname")); ?></a></li>
                                <li><a class="dropdown-item" href="<?php echo e(route("jobSave")); ?>">Công việc đã lưu</a></li>
                                <li><a class="dropdown-item" href="<?php echo e(route("logout")); ?>">Đăng xuất</a></li>
                            </ul>
                        </li>
                        <?php else: ?>
                        <li class="nav-item">
                            <a class="nav-link" href="<?php echo e(route("login")); ?>">Sign In</a>
                        </li>
                        <?php endif; ?>
                        <li class="button-group">
                            <a href="<?php echo e(route("employer.home")); ?>" class="button btn btn-common">Tuyển dụng</a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="mobile-menu" data-logo="<?php echo e(asset("candidate/imgs/logo-mobile.png")); ?>"></div>
    </nav>
    <?php else: ?>
    <nav class="navbar navbar-expand-lg fixed-top scrolling-navbar navbar-post">
        <div class="container d-block">
            <div class="top position-relative">
                <form action="<?php echo e(route("post")); ?>" class="top-search-post">
                    <input type="text" placeholder="Tìm kiếm" value="<?php echo e(request("search")); ?>" name="search" id="search" class="form-control form-control-sm d-inline-block">
                    <button class="btn-search"><i class="fas fa-search"></i></button>
                </form>
            </div>
            <div class="theme-header clearfix">
                <div class="navbar-header">
                    <button class="navbar-toggler" type="button" data-toggle="collapse" data-target="#main-navbar" aria-controls="main-navbar" aria-expanded="false" aria-label="Toggle navigation">
                        <span class="navbar-toggler-icon"></span>
                        <span class="lni-menu"></span>
                        <span class="lni-menu"></span>
                        <span class="lni-menu"></span>
                    </button>
                    <a href="<?php echo e(route("home")); ?>" class="navbar-brand"><img src="<?php echo e(asset("candidate/imgs/logo.png")); ?>" alt="jobber"></a>
                </div>
                <div class="collapse navbar-collapse" id="main-navbar">
                    <ul class="navbar-nav mr-auto w-100 justify-content-end">
                        <li class="nav-item dropdown">
                            <a href="<?php echo e(route("home")); ?>" class="nav-link dropdown-toggle" href="?d">
                                Việc Làm
                            </a>
                        </li>
                        <li class="nav-item <?php echo e(setMenuActive("post.home","candidate")); ?>">
                            <a href="<?php echo e(route("post.home")); ?>" class="nav-link dropdown-toggle" href="?module=post&action=cat">
                                Trang chủ
                            </a>
                        </li>
                        <?php $__currentLoopData = $setMenuPost["menus"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $menu): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item">
                            <a href="<?php echo e(route("post",["cat"=>$menu->Cat_ID])); ?>" class="nav-link dropdown-toggle" href="?module=post&action=cat">
                                <?php echo e($menu->Cat_Title); ?>

                            </a>
                        </li>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        <li class="nav-item dropdown">
                            <a href="" class="nav-link dropdown-toggle btn-open-search-post"><i class="fas fa-search"></i></a>
                        </li>
                    </ul>
                </div>
            </div>
        </div>
        <div class="mobile-menu bg-white align-items-center justify-content-between" data-logo="<?php echo e(asset("candidate/imgs/logo-mobile.png")); ?>">
            <div class="btn-option">
                <a href="" class="nav-link dropdown-toggle btn-open-search-post"><i class="fas fa-search"></i></a>
            </div>
        </div>
    </nav>
    <?php endif; ?>
    <?php if(!empty($setSearchMenu)): ?>
    <div class="container">
        <div class="contents pb-2">
            <form action="<?php echo e(route("job")); ?>" class="row job-search-form mx-0">
                <div class="col-md-4">
                    <div class="form-group">
                        <input class="form-control" type="text" value="<?php echo e(request("Job_Title")); ?>" name="Job_Title" placeholder="Tên công việc">
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <div class="search-category-container">
                            <label class="styled-select">
                                <select name="Province_ID">                          
                                    <option value="">Tỉnh Thành</option>         
                                    <?php $__currentLoopData = $dataSearch["provinces"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($province->Province_ID); ?>" <?php if($province->Province_ID == request("Province_ID")): ?> selected <?php endif; ?>><?php echo e($province->Province_Name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </label>
                        </div>
                    </div>
                </div>
                <div class="col-md-3">
                    <div class="form-group">
                        <div class="search-category-container">
                            <label class="styled-select">
                                <select name="Specialize_ID">
                                    <option value="">Nghành</option>
                                    <?php $__currentLoopData = $dataSearch["specializes"]; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialize): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                        <option value="<?php echo e($specialize->Specialize_ID); ?>" <?php if($specialize->Specialize_ID == request("Specialize_ID")): ?> selected <?php endif; ?>><?php echo e($specialize->Name); ?></option>
                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                </select>
                            </label>
                        </div>
                        <i class="fas fa-tools"></i>
                    </div>
                </div>
                <div class="col-md-2">
                    <button type="submit" class="button w-100"><i class="lni-search"></i></button>
                </div>
                <div class="col-12 my-2">
                    <a href="#" id="btn-open-seach-advanced" class="text-white float-right">Chọn tìm kiếm nâng cao</a>
                </div>
                <div class="col-12 seach-adanced">
                </div>
            </form>
        </div>
    </div>
    <?php endif; ?>
    <?php if(!empty($setSearchCompany)): ?>        
    <div id="box-search-company">
        <div class="container">
            <div class="box-search">
                <h5 class="title">Tra cứu thông tin trên The Hunt</h5>
                <form class="form-search" action="">
                    <div class="form-group">
                        <button class="btn-search"><i class="fas fa-search"></i></button>
                        <input type="text" class="form-control" id="search" name="search" value="<?php echo e(request("search")); ?>">
                    </div>
                    <div class="form-group">
                        <button class="btn-search"><i class="fas fa-search"></i> Tìm</button>
                    </div>
                </form>
            </div>
        </div>
    </div>
    <?php endif; ?>

    <?php if(!empty($setHome)): ?>
    <div class="container">
        <div class="row space-100">
            <div class="col-lg-7 col-md-12 col-xs-12">
                <div class="contents">
                    <h2 class="head-title">Find the <br> job that fits your life</h2>
                    <p>Aliquam vestibulum cursus felis. In iaculis iaculis sapien ac condimentum. Vestibulum congue posuere lacus, id tincidunt nisi porta sit amet. Suspendisse et sapien varius, pellentesque dui non.</p>
                    <div class="job-search-form">
                        <form action="<?php echo e(route("job")); ?>">
                            <div class="row">
                                <div class="col-lg-5 col-md-5 col-xs-12">
                                    <div class="form-group">
                                        <input class="form-control" name="Job_Title" type="text" placeholder="Tìm kiếm việc làm" value="<?php echo e(request("Job_Title")); ?>">
                                    </div>
                                </div>
                                <div class="col-lg-5 col-md-5 col-xs-12">
                                    <div class="form-group">
                                        <div class="search-category-container">
                                            <label class="styled-select">
                                                <select name="Job_Type">
                                                    <?php $__currentLoopData = __("user.Job_Type"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $jobType): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                                        <option value="<?php echo e($key); ?>" <?php if(request("Job_Type")==$key): ?> selected  <?php endif; ?>><?php echo e($jobType); ?></option>
                                                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                                </select>
                                            </label>
                                        </div>
                                        <i class="lni-map-marker"></i>
                                    </div>
                                </div>
                                <div class="col-lg-2 col-md-2 col-xs-12">
                                    <button type="submit" class="button"><i class="lni-search"></i></button>
                                </div>
                            </div>
                        </form>
                    </div>
                </div>
            </div>
            <div class="col-lg-5 col-md-12 col-xs-12">
                <div class="intro-img">
                    <img src="<?php echo e(asset("candidate/imgs/intro.png")); ?>" alt="trang chủ jobber">
                </div>
            </div>
        </div>
    </div>
    <?php endif; ?>
    </header><?php /**PATH C:\xampp\htdocs\laravel\project_cv\jobber\resources\views/candidate/include/header.blade.php ENDPATH**/ ?>