
<?php $__env->startSection("title","Đăng ký tài khoản nhà tuyển dụng"); ?>
<?php $__env->startSection("modal-login"); ?>
##parent-placeholder-a0b1263f353849aed3b4fdd1faa905d742a457ed##
<?php $__env->stopSection(); ?>
<?php $__env->startSection("css"); ?>
    
    <link rel="stylesheet" href="<?php echo e(asset("admin/plugins/select2/css/select2.min.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("admin/plugins/select2/css/select2-bootstrap4.css")); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection("js"); ?>
    
    <script src="<?php echo e(asset("admin/plugins/select2/js/select2.min.js")); ?>"></script>
    <script>
        $('#Specialize_ID').select2({
        minimumInputLength: 2,
        ajax: {
            url: '<?php echo e(route("employer.data.specialize")); ?>',
            type: 'GET',
            dataType: 'json',
            data: function (params) {
                return {Name: params.term};
            },
            processResults: function (data, params) {
                return {results: $.map(data, function (item) {return {text: item.Name,id: item.Specialize_ID,data: item};})
                };
            }
        }
    });
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("header"); ?>
    <?php echo $__env->make("employer.include.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div id="box-reg" class="container">
    <div class="row">
        <div class="col-12">
            <h3 class="title py-3">Đăng ký nhà tuyển dụng</h3>
        </div>
        <div class="col-md-8 box-left box-form mb-4">
            <form action="<?php echo e(route("employer.reg")); ?>" id="form-reg" method="post">
                <?php echo csrf_field(); ?>
                <div class="login-info py-4 border-bottom border-primary">
                    <h5 class="title pb-4 ">Thông tin đăng nhập</h5>
                    <div class="form-group <?php $__errorArgs = ["Fullname"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="Fullname">Họ và tên: *</label>
                        <input type="text" id="Fullname" class="form-control" value="<?php echo e(old("Fullname")); ?>" name="Fullname">
                        <?php $__errorArgs = ["Fullname"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="message"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group <?php $__errorArgs = ["User_Email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="User_Email">Email: *</label>
                        <input type="text" id="User_Email" class="form-control" value="<?php echo e(old("User_Email")); ?>" name="User_Email">
                        <small class="note font-italic">Jobber khuyến nghị đăng ký bằng email công ty (theo tên miền website công ty) để được hỗ trợ duyệt tin nhanh & đăng tin không giới hạn.</small>
                        <?php $__errorArgs = ["User_Email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="message"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group <?php $__errorArgs = ["User_Password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="User_Password">Mật khẩu: *</label>
                        <input type="password" id="User_Password" class="form-control" name="User_Password">
                        <?php $__errorArgs = ["User_Password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="message"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group <?php $__errorArgs = ["Re_User_Password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="Re_User_Password">Mật khẩu xác nhận: *</label>
                        <input type="password" id="Re_User_Password" class="form-control" name="Re_User_Password">
                        <?php $__errorArgs = ["Re_User_Password"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="message"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                </div>
                <div class="company-info py-3">
                    <h5 class="title py-4">Thông tin tuyển dụng</h5>
                    <div class="form-group <?php $__errorArgs = ["Company_Name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="Company_Name">Tên công ty: </label>
                        <input type="text" id="Company_Name" class="form-control" value="<?php echo e(old("Company_Name")); ?>" name="Company_Name">
                        <?php $__errorArgs = ["Company_Name"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="message"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group <?php $__errorArgs = ["Specialize_ID"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="Specialize_ID">Lĩnh vực kinh doanh: </label>
                        <select name="Specialize_ID" class="form-control" id="Specialize_ID">
                            <option value="">Chọn lĩnh vực</option>
                        </select>
                        <?php $__errorArgs = ["Specialize_ID"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="message"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group <?php $__errorArgs = ["Company_Address"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="Company_Address">Địa chỉ: </label>
                        <input type="text" id="Company_Address" class="form-control" value="<?php echo e(old("Company_Address")); ?>" name="Company_Address">
                        <?php $__errorArgs = ["Company_Address"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="message"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <!-- gender -->
                    <div class="form-group  <?php $__errorArgs = ["Gender"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="">Giới tính: *</label>
                        <div class="custom-control custom-checkbox d-flex">
                            <div class="check-male pr-5">
                                <input type="checkbox" class="custom-control-input" id="male" value="0" name="Gender">
                                <label class="custom-control-label" for="male">Nam</label>
                            </div>
                            <div class="check-female">
                                <input type="checkbox" class="custom-control-input" id="female" value="1" name="Gender">
                                <label class="custom-control-label" for="female">Nữ</label>
                            </div>
                        </div>
                        <?php $__errorArgs = ["Gender"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="message"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <!-- end gender -->
                </div>
                <div class="form-group">
                    <!-- import recaptcha -->
                    
                </div>
                <!-- submit -->
                <div class="form-group">
                    <button class="btn btn-outline-primary">Đăng ký</button>
                </div>
                <!-- endsubmit -->
            </form>
        </div>
        <div class="col-md-4 box-right box-advertisement">
            <div class="box-regulation">
                <h5 class="title">Quy định Đăng ký tài khoản</h5>
                <p class="note">
                    Để đảm bảo chất lượng dịch vụ, Jobber <span class="text-dangder">không cho phép một người dùng tạo nhiều tài khoản khác nhau.</span> Nếu phát hiện vi phạm, <span class="text-danger">Jobber sẽ ngừng cung cấp dịch vụ tới tất cả các tài khoản trùng lặp hoặc chặn toàn bộ truy cập tới hệ thống website của TopCV</span>.
                    Đối với trường hợp khách hàng đã sử dụng hết 3 tin tuyển dụng miễn phí, Jobber hỗ trợ kích hoạt đăng tin tuyển dụng không giới hạn sau khi quý doanh nghiệp cung cấp thông tin giấy phép kinh doanh.
                    Mọi thắc mắc vui lòng liên hệ Hotline CSKH: (024) 7107 9799 - 0862 69 19 29
                </p>
            </div>
            <a href="" class="box-thumbnail"><img class="thumbnail img-fluid" src="https://employer.vietnamworks.com/bundles/naviworksuser/img/BANNER-03-1600X1000.png" alt=""></a>
        </div>
    </div>
</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("employer.master.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\project_cv\jobber\resources\views/employer/user/reg.blade.php ENDPATH**/ ?>