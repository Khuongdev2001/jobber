<!DOCTYPE html>
<html lang="en">

<head>
    <meta charset="utf-8">
    <meta name="viewport" content="width=device-width, initial-scale=1, shrink-to-fit=no">
    <meta name="keywords" content="Bootstrap, Landing page, Template, Registration, Landing">
    <meta name="viewport" content="width=device-width, initial-scale=1, maximum-scale=1">
    <!-- Favicon -->
    <link href="<?php echo e(asset("employer/img/logo.svg")); ?>" rel="shortcut icon" />
    <title><?php echo $__env->yieldContent("title"); ?></title>
    <link rel="stylesheet" href="<?php echo e(asset("candidate/framework/bootstrap/css/bootstrap.min.css")); ?>">
    <link rel="stylesheet" href="https://fonts.googleapis.com/css?family=Rubik:400,500,700">
    <link rel="stylesheet" href="<?php echo e(asset("candidate/fonts/fontawesome/css/all.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("candidate/css/line-icons.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("candidate/css/slicknav.min.css")); ?>" >
    <link rel="stylesheet" href="<?php echo e(asset("candidate/plugin/animate/css/animate.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("candidate/css/main.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("candidate/css/responsive.css")); ?>">
    
    <link rel="stylesheet" href="<?php echo e(asset("admin/plugins/notifications/css/lobibox.min.css")); ?>">
    <?php echo $__env->yieldContent("css"); ?>
</head>

<body>
<?php echo $__env->make("candidate/include/header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php echo $__env->yieldContent("content"); ?>   
<footer>
    <div id="subscribe" class="section bg-cyan">
        <div class="container">
            <div class="row">
                <div class="col-lg-6 col-md-6 col-xs-12">
                    <div class="subscribe-form">
                        <div class="form-wrapper">
                            <div class="sub-title">
                                <h3>Subscribe Our Newsletter</h3>
                                <p>Lorem ipsum dolor sit amet, consectetur adipiscing elit ellentesque dignissim quam et metus dolor sit amet,.</p>
                            </div>
                            <form>
                                <div class="row">
                                    <div class="col-12 form-line">
                                        <div class="form-group form-search">
                                            <input type="email" class="form-control" name="email" placeholder="Enter Your Email">
                                            <button type="submit" class="btn btn-common btn-search">Submit</button>
                                        </div>
                                    </div>
                                </div>
                            </form>
                        </div>
                    </div>
                </div>
                <div class="col-lg-6 col-md-6 col-xs-12">
                    <div class="img-sub">
                        <img class="img-fluid" src="https://preview.uideck.com/items/thehunt/assets/img/sub.png" alt="">
                    </div>
                </div>
            </div>
        </div>
    </div>
    <section class="footer-Content">
        <div class="container">
            <ul id="list-key-seach-post">
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>
                <li class="item"><a href="">cv là g</a></li>

            </ul>
        </div>
    </section>
    <div id="copyright">
        <div class="container">
            <div class="row">
                <div class="col-md-12">
                    <div class="site-info text-center">
                        Nguyễn Hữu Khương
                    </div>
                </div>
            </div>
        </div>
    </div>
</footer>
<a href="#" class="back-to-top">
    <i class="lni-arrow-up"></i>
</a>
<a id="chat-support" class="dropdown-toggle" href="#" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
    <i class="fab fa-facebook-messenger"></i>
</a>
<div id="preloader">
    <div class="loader" id="loader-1"></div>
</div>
<script src="<?php echo e(asset("candidate/library/jquery/js/jquery-min.js")); ?>"></script>
<script src="<?php echo e(asset("candidate/framework/bootstrap/js/popper.min.js")); ?>"></script>
<script src="<?php echo e(asset("candidate/framework/bootstrap/js/bootstrap.min.js")); ?>"></script>
<script src="<?php echo e(asset("candidate/js/color-switcher.js")); ?>"></script>
<script src="<?php echo e(asset("candidate/plugin/carousel/js/owl.carousel.min.js")); ?>"></script>
<script src="<?php echo e(asset("candidate/library/jquery/js/jquery.slicknav.js")); ?>"></script>
<script src="<?php echo e(asset("candidate/library/jquery/js/jquery.counterup.min.js")); ?>"></script>
<script src="<?php echo e(asset("candidate/js/waypoints.min.js")); ?>"></script>
<script src="<?php echo e(asset("candidate/js/form-validator.min.js")); ?>"></script>
<script src="<?php echo e(asset("candidate/js/contact-form-script.js")); ?>"></script>
<!-- plugin lazy loading -->
<script src="<?php echo e(asset("candidate/js/main.js")); ?>"></script>

<script src="<?php echo e(asset("admin/plugins/notifications/js/lobibox.min.js")); ?>"></script>
<script src="<?php echo e(asset("admin/plugins/notifications/js/notifications.min.js")); ?>"></script>
<script src="<?php echo e(asset("admin/plugins/notifications/js/notification-custom-script.js")); ?>"></script>
    
    <?php if($errors->any() || session("error") || session("success")): ?>
    <script>
        <?php $__currentLoopData = $errors->all(); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $error): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
              error_noti({ title:"Lỗi Người Dùng", message:"<?php echo e($error); ?>"})
        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>

        <?php if(session("error")): ?>
            error_noti({ title:"<?php echo e(session('error.title')); ?>", message:"<?php echo e(session('error.message')); ?>"})
        <?php endif; ?>        

        <?php if(session("success")): ?>
            success_noti({title:"<?php echo e(session('success.title')); ?>",message:"<?php echo e(session('success.message')); ?>"} )
        <?php endif; ?>
    </script>  
    <?php endif; ?>
    <script>
    $(document).on("click", "#btn-open-seach-advanced", function() {
        $(this).attr("id", "btn-close-seach-advanced");
        $(this).text("Đóng tìm kiếm nâng cao")
        $(".job-search-form .seach-adanced").append(`<div class="row"><div class="col-md-3"><div class="form-group"><div class="search-category-container"><label class="styled-select"></label></div></div></div><div class="col-md-3"><div class="form-group"><div class="search-category-container"><label class="styled-select"><select name="Job_Type">
            <?php $__currentLoopData = __("user.Job_Type"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($key); ?>"><?php echo e($item); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select></label></div><i class = "far fa-clock"></i></div></div><div class = "col-md-3" ><div class = "form-group" ><div class = "search-category-container" ><label class="styled-select">
                <select name="Experience">
            <?php $__currentLoopData = __("user.Experience"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                <option value="<?php echo e($key); ?>"><?php echo e($item); ?></option>
            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
            </select>
            </label></div> <i class = "far fa-building" ></i></div></div></div>`)
    })
    $(document).on("click", "#btn-close-seach-advanced", function() {
        $(this).attr("id", "btn-open-seach-advanced");
        $(this).text("Chọn tìm kiếm nâng cao")
        $(".job-search-form .seach-adanced").empty();
    })
    </script>
<?php echo $__env->yieldContent("js"); ?>
</body>

</html><?php /**PATH C:\xampp\htdocs\laravel\project_cv\jobber\resources\views/candidate/master/index.blade.php ENDPATH**/ ?>