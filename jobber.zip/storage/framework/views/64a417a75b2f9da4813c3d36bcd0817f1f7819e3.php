

<?php $__env->startSection("title","Danh sách ứng viên phù hợp nhất"); ?>

<?php $__env->startSection("header"); ?>
    <?php echo $__env->make("employer.include.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<section class="space-ptb">
    <div class="container">
        <div class="section-title center">
            <h2 class="title">Danh sách ứng viên tiềm năng</h2>
        </div>
        <form action="" class="row">
            <div class="col-lg-3 mb-0">
                <div class="sidebar">
                    <div class="widget">
                        <div class="search">
                            <i class="fas fa-search"></i>
                            <input class="form-control" value="<?php echo e(request("search")); ?>" name="search" type="text" placeholder="Tìm kiếm ứng viên">
                        </div>
                    </div>                  
                    <div class="widget">
                        <div class="specialist">
                            <select class="form-control basic-select" name="Specialize">
                                <option value="">Chọn Ngành</option>
                                <?php $__currentLoopData = $specializes; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $specialize): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($specialize->Specialize_ID); ?>" <?php if(request("Specialize")==$specialize->Specialize_ID): ?> selected <?php endif; ?>><?php echo e($specialize->Name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="widget">
                        <div class="Experience">
                            <select class="form-control basic-select" name="Experience">
                                <option value="">Chọn kinh nghiệm</option>
                                <?php $__currentLoopData = __("user.Experience"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($key); ?>" <?php if(request("Experience")==$key): ?> selected <?php endif; ?> ><?php echo e($item); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="widget">
                        <div class="locations">
                            <select class="form-control basic-select" name="Province">
                                <option value="">Chọn tỉnh</option>
                                <?php $__currentLoopData = $provinces; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $province): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                    <option value="<?php echo e($province->Province_ID); ?>" <?php if(request("Province")==$province->Province_ID): ?> selected <?php endif; ?>><?php echo e($province->Province_Name); ?></option>
                                <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                            </select>
                        </div>
                    </div>
                    <div class="widget">
                        <div class="widget-add">
                            <img class="img-fluid" src="images/add-banner.png" alt="">
                        </div>
                    </div>
                </div>
            </div>
            <div class="col-lg-9">
                <div class="row mb-4">
                    <div class="col-12">
                        <h6 class="mb-0">Hiển <span class="text-primary"><?php echo e($candidates->total()); ?> Ứng Viên</span></h6>
                    </div>
                </div>
                <div class="row">
                    <?php $__currentLoopData = $candidates; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $candidate): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <div class="col-12">
                            <div class="candidate-list">
                                <div class="candidate-list-image">
                                    <img class="img-fluid" src="<?php echo e(asset($candidate->Avatar)); ?>" alt="<?php echo e($candidate->Fullname); ?>">
                                </div>
                                <div class="candidate-list-details">
                                    <div class="candidate-list-info">
                                        <div class="candidate-list-title">
                                            <h5 class="mb-0"><a href="<?php echo e(route("employer.filter.candidate",$candidate->Candidate_ID)); ?>"><?php echo e($candidate->Fullname); ?></a></h5>
                                        </div>
                                        <div class="candidate-list-option">
                                            <ul class="list-unstyled">
                                                <li><i class="fas fa-filter pr-1"></i>Lĩnh vực làm việc:<span><?php echo e($candidate->Specialize_Name); ?><span></li>
                                                <li><i class="fas fa-map-marker-alt pr-1"></i>làm việc tại: <span><?php echo e($candidate->Province_Name); ?></span></li>
                                                <?php
                                                $wage="Thỏa thuận";
                                                if($candidate->Wage_From || $candidate->Wage_To){
                                                    $wage=$candidate->Wage_From ? "Từ".currency($candidate->Wage_From) : " Đến ".currency($candidate->Wage_To);
                                                }
                                                if($candidate->Wage_From && $candidate->Wage_To){
                                                    $wage="Từ ".currency($candidate->Wage_From)." Đến ".currency($candidate->Wage_To); 
                                                }
                                                ?>
                                                <li>Mức lương: <span><?php echo e($wage); ?></span></li>
                                                <li>Kinh nghiệm: <span>1 năm</span></li>
                                            </ul>
                                        </div>
                                    </div>
                                </div>
                                <div class="candidate-list-favourite-time">
                                    <a href="<?php echo e(route("employer.candidate.save.option",["id"=>$candidate->Candidate_ID,"status"=>1])); ?>" class="candidate-list-favourite order-2" href="#"><i class="far fa-heart"></i></a>
                                </div>
                            </div>
                        </div>                                           
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>    
                </div>
                <div class="row">
                    <div class="col-12 text-center mt-4 mt-sm-5">
                        <?php echo e($candidates->appends(["Specialize"=>request("Specialize"),"Province"=>request("Province"),"search"=>request("search"),"Experience"=>request("Experience")])->links()); ?>

                    </div>
                </div>
            </div>
        </form>
    </div>
</section>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("employer.master.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\project_cv\jobber\resources\views/employer/candidate/index.blade.php ENDPATH**/ ?>