
<?php $__env->startSection("title","Đăng tin tuyển dụng"); ?>
<?php $__env->startSection("css"); ?>
<link rel="stylesheet" href="http://themes.potenzaglobalsolutions.com/html/jobber/css/datetimepicker/datetimepicker.min.css">

<link rel="stylesheet" href="<?php echo e(asset("admin/plugins/select2/css/select2.min.css")); ?>">
<link rel="stylesheet" href="<?php echo e(asset("admin/plugins/select2/css/select2-bootstrap4.css")); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection("js"); ?>
<script src="https://cdn.tiny.cloud/1/vbzkm84qcbxrq5hsachp4rnckre9eor9ynuypftf4ue9e8g3/tinymce/5/tinymce.min.js" referrerpolicy="origin"></script>
<script src="<?php echo e(asset("employer/plugins/jquery-appear/jquery.appear.js")); ?>"></script>
<script src="<?php echo e(asset("employer/plugins/jquery-count-to/jquery.countTo.js")); ?>"></script>

<script src="<?php echo e(asset("admin/plugins/select2/js/select2.min.js")); ?>"></script>
<script src="http://themes.potenzaglobalsolutions.com/html/jobber/js/datetimepicker/moment.min.js"></script>
<script src="http://themes.potenzaglobalsolutions.com/html/jobber/js/datetimepicker/datetimepicker.min.js"></script>
<script>
    $('#Specialize_ID').select2({
        minimumInputLength: 2,
        ajax: {
            url: '<?php echo e(route("employer.data.specialize")); ?>',
            type: 'GET',
            dataType: 'json',
            data: function (params) {
                return {Name: params.term};
            },
            processResults: function (data, params) {
                return {results: $.map(data, function (item) {return {text: item.Name,id: item.Specialize_ID,data: item};})
                };
            }
        }
    });

    $('#Job_Province').select2({
        minimumInputLength: 2,
        ajax: {
            url: '<?php echo e(route("employer.data.province")); ?>',
            type: 'GET',
            dataType: 'json',
            data: function (params) {
                return {Province_Name: params.term};
            },
            processResults: function (data, params) {
                return {results: $.map(data, function (item) {return {text: item.Province_Name,id: item.Province_ID,data: item};})
                };
            }
        }
    });
    tinymce.init({
      selector: 'textarea',
      plugins: 'advlist autolink lists link image charmap print preview hr anchor pagebreak',
      toolbar_mode: 'floating',
   });
</script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("header"); ?>
    <?php echo $__env->make("employer.include.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="container">
    <div class="section-title center pt-5 pb-3">
        <h2 class="title">Thêm tin tuyển dụng mới</h2>
    </div>
    <div class="box-post-job-add">
        <form action="<?php if(empty($job)): ?><?php echo e(route("employer.job.add")); ?><?php else: ?><?php echo e(route("employer.job.update",$job->Job_Slug)); ?><?php endif; ?>" id="form-job-add" method="post">
            <?php echo csrf_field(); ?>
            <div class="row">
                <!-- Job_Title  -->
                <div class="form-group col-md-6 <?php $__errorArgs = ["Job_Title"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="Job_Title">Tiêu đề Công Việc:</label>
                    <input type="text" name="Job_Title" id="Job_Title" class="form-control" value="<?php echo e(old("Job_Title") ??  $job->Job_Title ?? ""); ?>">
                    <?php $__errorArgs = ["Job_Title"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="message"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <!-- end-Job_Title -->

                <!-- Specialize_ID  -->
                <div class="form-group col-md-6 <?php $__errorArgs = ["Specialize_ID"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="Specialize_ID">Nghành nghề:</label>
                    <select name="Specialize_ID" class="form-control" id="Specialize_ID">
                        <?php if(!empty($job)): ?>
                            <option value="<?php echo e($job->specialize->Specialize_ID); ?>"><?php echo e($job->specialize->Name); ?></option>
                        <?php endif; ?>
                    </select>
                    <?php $__errorArgs = ["Specialize_ID"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="message"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <!-- Specialize_ID -->
                
                <!-- Job_Type  -->
                <div class="form-group col-md-6">
                    <label for="Job_Type">Hình thức công việc:</label>
                    <select name="Job_Type" class="form-control basic-select <?php $__errorArgs = ["Job_Type"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="Job_Type">
                        <?php $__currentLoopData = __("user.Job_Type"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>" <?php if(!empty($job) && $key==$job->Job_Type): ?> selected <?php endif; ?>><?php echo e($item); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ["Job_Type"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="message"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <!-- Job_Type -->

                <!-- Job_Level  -->
                <div class="form-group col-md-6">
                    <label for="Job_Level">Cấp bậc công việc:</label>
                    <select name="Job_Level" class="form-control <?php $__errorArgs = ["Job_Level"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> basic-select" id="Job_Level">
                        <?php $__currentLoopData = __("user.Job_Level"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>" <?php if(!empty($job) && $key==$job->Job_Level): ?> selected <?php endif; ?>><?php echo e($item); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ["Job_Level"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="message"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <!-- Job_Level -->

                <!-- Number_People-  -->
                <div class="form-group col-md-6 <?php $__errorArgs = ["Number_People"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="Number_People">Số lượng tuyển:</label>
                    <input type="text" name="Number_People" id="Number_People" class="form-control" value="<?php echo e(old("Number_People") ?? $job->Number_People ?? ""); ?>">
                    <?php $__errorArgs = ["Number_People"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="message"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <!-- Number_People -->

                <!-- Job_Experience  -->
                <div class="form-group col-md-6">
                    <label for="Job_Experience">Yêu cầu kinh nghiệm:</label>
                    <select name="Job_Experience" class="form-control <?php $__errorArgs = ["Job_Experience"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?> basic-select" id="Job_Experience">
                        <?php $__currentLoopData = __("user.Experience"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>" <?php if(!empty($job) && $job->Job_Experience==$key): ?> selected <?php endif; ?>><?php echo e($item); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ["Job_Experience"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="message"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <!-- Job_Experience -->

                <!-- Job_Province -->
                <div class="form-group col-md-6">
                    <label for="Job_Province">Tỉnh thành:</label>
                    <select name="Job_Province" class="form-control <?php $__errorArgs = ["Job_Province"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="Job_Province">
                        <?php if(!empty($job)): ?>
                            <option value="<?php echo e($job->province->Province_ID); ?>"><?php echo e($job->province->Province_Name); ?></option>
                        <?php endif; ?>
                    </select>
                    <?php $__errorArgs = ["Job_Province"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="message"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <!-- Job_Province-->

                <!-- Job_Address  -->
                <div class="form-group col-md-6">
                    <label for="Job_Address">Địa chỉ làm việc:</label>
                    <input type="text" name="Job_Address" id="Job_Address" value="<?php echo e(old("Job_Address") ?? $job->Job_Address ??""); ?>" class="form-control <?php $__errorArgs = ["Job_Address"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ["Job_Address"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="message"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <!-- Job_Address -->

                <!-- Wage_From  -->
                <div class="form-group col-md-6">
                    <label for="Wage_From">Mức lương từ:</label>
                    <input type="text" name="Wage_From" id="Wage_From" value="<?php echo e(old("Wage_From") ?? $job->Wage_From ?? ""); ?>" class="form-control <?php $__errorArgs = ["Wage_From"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ["Wage_From"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="message"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>    
                </div>
                <!-- Wage_From -->

                <!-- Wage_To  -->
                <div class="form-group col-md-6">
                    <label for="Wage_To">Mức lương đến:</label>
                    <input type="text" name="Wage_To" id="Wage_To" value="<?php echo e(old("Wage_To") ?? $job->Wage_To ?? ""); ?>" class="form-control <?php $__errorArgs = ["Wage_To"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <?php $__errorArgs = ["Wage_To"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="message"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <!-- Wage_To -->

                <!-- Job_Description -->
                <div class="form-group col-md-12 <?php $__errorArgs = ["Job_Description"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error  <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="Job_Description">Mô tả công việc: </label>
                    <textarea name="Job_Description" id="Job_Description" cols="30" rows="5" class="form-control"><?php echo e(old("Job_Description") ?? $job->Job_Description ?? ""); ?></textarea>
                    <?php $__errorArgs = ["Job_Description"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="message"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <!-- end-Job_Description -->

                <!-- Job_Interest  -->
                <div class="form-group col-md-12">
                    <label for="Job_Interest">Quyền lợi công việc: </label>
                    <textarea name="Job_Interest" id="Job_Interest" cols="30" rows="5" class="form-control <?php $__errorArgs = ["Job_Interest"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old("Job_Interest") ?? $job->Job_Interest ?? ""); ?></textarea>
                    <?php $__errorArgs = ["Job_Interest"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="message"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>   
                </div>
                <!-- end Job_Interest -->

                <!-- Job_Required  -->
                <div class="form-group col-md-12">
                    <label for="Job_Required">Yêu cầu công việc: </label>
                    <textarea name="Job_Required" id="Job_Required" cols="30" rows="5" class="form-control <?php $__errorArgs = ["Job_Required"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>"><?php echo e(old("Job_Required") ?? $job->Job_Required ?? ""); ?></textarea>
                    <?php $__errorArgs = ["Job_Required"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="message"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>   
                </div>
                <!-- end job required -->
                

                <!-- Required_Gender -->
                <div class="form-group col-12">
                    <label for="">Yêu cầu giới tính: *</label>
                    <?php
                        $checked=[];
                        $checked[$job->Required_Gender ?? ""]="checked";
                    ?>
                    <div class="custom-control custom-checkbox d-flex">
                        <div class="check-male pr-5">
                            <input type="radio" name="Required_Gender" class="custom-control-input" <?php echo e($checked[1] ?? ""); ?> value="1" id="male">
                            <label class="custom-control-label" for="male">Nam</label>
                        </div>
                        <div class="check-female pr-5">
                            <input type="radio" name="Required_Gender" class="custom-control-input" <?php echo e($checked[2] ?? ""); ?> value="2" id="female">
                            <label class="custom-control-label" for="female">Nữ</label>
                        </div>
                        <div class="check-female">
                            <input type="radio" name="Required_Gender" class="custom-control-input" <?php echo e($checked[0] ?? "checked"); ?> value="0" id="not-required">
                            <label class="custom-control-label" for="not-required">Không yêu</label>
                        </div>
                    </div>
                </div>
                <!-- end Required_Gender -->

                <!-- Job_Limit -->
                <div class="form-group col-md-6 datetimepickers">
                    <label>Hạn chót nộp hồ sơ: </label>
                    <div class="input-group date" id="datetimepicker-01" data-target-input="nearest">
                        <input type="text" class="form-control datetimepicker-input" placeholder="Date" name="Job_Limit" data-target="#datetimepicker-01" value="<?php echo e($job->Job_Limit ?? ""); ?>">
                        <div class="input-group-append" data-target="#datetimepicker-01" data-toggle="datetimepicker">
                            <div class="input-group-text"><i class="far fa-calendar-alt"></i></div>
                        </div>
                    </div>
                    <!-- end Job_Limit -->
                </div>

                <!-- btn post job -->
                <div class="form-group col-12">
                    <?php if(empty($job)): ?>
                        <a href="javascript:void(0)" class="btn btn-outline-success" data-toggle="modal" data-target=".modal-select-package"><?php echo e(count($servicePost) ? "Lưu và tiếp tục" :"Bạn cần mua gói để tiếp tục"); ?></a>
                    <?php else: ?>
                        <button class="btn btn-success">Lưu</button>
                    <?php endif; ?>
                </div>
                <!-- end post job -->

                <?php if(empty($job)): ?>
                <!-- modal apply package -->
                <div class="modal fade modal-select-package" tabindex="-1" role="dialog" aria-hidden="true">
                    <div class="modal-dialog modal-lg modal-dialog-centered" role="document">
                        <div class="modal-content">
                            <div class="modal-header">
                                <h5 class="modal-title">Áp dụng gói với tin</h5>
                                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                                    <span aria-hidden="true">&times;</span>
                                </button>
                            </div>
                            <div class="modal-body">
                                <!-- Package_Post_Buy -->
                                <div class="form-group">
                                    <label for="Package_Post_Buy">Gói đăng tin: </label>
                                    <select name="Package_Post_Buy" class="form-control" id="Package_Post_Buy">
                                        <option value="">Chọn gói đăng tin</option>
                                        <?php $__currentLoopData = $servicePost; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($service->Service_ID); ?>"><?php echo e(__("package.{$service->Package_ID}.Package_Name")); ?>(<?php echo e($service->Total); ?> Gói)</option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <!-- Package_Effect_Buy -->
                                <div class="form-group">
                                    <label for="Package_Effect_Buy">Gói hiệu ứng:</label>
                                    <select name="Package_Effect_Buy" class="form-control" id="Package_Effect_Buy">
                                        <option value="">Chọn gói hiệu ứng</option>
                                        <?php $__currentLoopData = $serviceEffect; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                                            <option value="<?php echo e($service->Service_ID); ?>"><?php echo e(__("package.{$service->Package_ID}.Package_Name")); ?>(<?php echo e($service->Total); ?> Gói)</option>
                                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                                    </select>
                                </div>
                                <div class="box-note">
                                    <small class="note text-danger font-italic">
                                        Chú ý khi chọn gói hợp lý bạn sẽ mất gói đó, và tin tuyển dụng bạn sẽ phải xét duyệt mới có thể đăng. Nếu tin tuyển dụng không hợp lệ, gói sẽ được hoàn lại
                                    </small>
                                </div>
                            </div>
                            <div class="modal-footer">
                                <button class="btn btn-success">Áp dung</button>
                            </div>
                        </div>
                    </div>
                </div>
                <?php endif; ?>
                <!-- end modal  -->
        </form>
    </div>
</div>


<?php $__env->stopSection(); ?>
<?php echo $__env->make("employer.master.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\project_cv\jobber\resources\views/employer/job/add.blade.php ENDPATH**/ ?>