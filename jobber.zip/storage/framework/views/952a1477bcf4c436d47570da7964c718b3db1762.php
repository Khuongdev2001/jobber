
<?php $__env->startSection("title","Trang Tổng Quan"); ?>
<?php $__env->startSection("css"); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("js"); ?>
<script src="<?php echo e(asset("employer/plugins/jquery-appear/jquery.appear.js")); ?>"></script>
<script src="<?php echo e(asset("employer/plugins/jquery-count-to/jquery.countTo.js")); ?>"></script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("header"); ?>
    <?php echo $__env->make("employer.include.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="container">
    <div class="section-title center pt-5 pb-3">
        <h2 class="title">Số liệu thống kê của của bạn</h2>
    </div>
    <div class="box-static post">
        <div class="post-job">
            <ul class="row list-unstyled">
                <!-- posted -->
                <li class="col-md-3">
                    <div class="posted">
                        <h6 class="title">Bài hiển thị</h6>
                        <span class="number counter" data-number="10">0</span>
                        <a href="" class="see-more">Xem thêm</a>
                    </div>
                </li>
                <!-- end post -->
                <!-- post save -->
                <li class="col-md-3">
                    <div class="post-save">
                        <h6 class="title">Bài đã lưu</h6>
                        <span class="number counter" data-number="20">
                            0
                        </span>
                        <a href="" class="see-more">Xem thêm</a>
                    </div>
                </li>
                <!-- end post -->
                <!-- post-limit -->
                <li class="col-md-3">
                    <div class="post-limit">
                        <h6 class="title">Bài hết hạng </h6>
                        <span class="counter number" data-number="40">
                            0
                        </span>
                        <a href="" class="see-more">Xem thêm</a>
                    </div>
                </li>
                <!-- end post -->
                <li class="col-md-3">
                    <!-- fillter package -->
                    <div class="fillter-package">
                        <h6 class="title">Số điểm lọc hồ sơ</h6>
                        <span class="number counter" data-number="40">
                            0
                        </span>
                        <a href="" class="buy-more">Mua thêm</a>
                    </div>
                    <!-- end fillter package -->
                </li>
            </ul>
        </div>
        <div class="package">
            <!-- post job package  -->
            <div class="post-job py-4">
                <h3 class="title">Gói dịch vụ</h3>
                <ul class="row list-unstyled">
                    <?php $__currentLoopData = $services; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $service): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li class="col-md-3">
                        <div class="package-basic">
                            <h6 class="title"><?php echo e(__("package.{$service->Package_ID}.Package_Name")); ?></h6>
                            <span class="number counter" data-number="<?php echo e($service->Total); ?>">
                               <?php echo e($service->Total); ?>                              
                            </span>                        
                            
                            <a href="<?php echo e(route("employer.product.buy")); ?>" class="">Mua thêm</a>
                        </div>
                    </li>  
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>                  
                </ul>
            </div>            
        </div>
    </div>

</div>
<?php $__env->stopSection(); ?>
<?php echo $__env->make("employer.master.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\project_cv\jobber\resources\views/employer/dashboard/index.blade.php ENDPATH**/ ?>