<?php
return
    [
        1 => [
            "Package_Name" => "Đăng tin cơ bản:"
        ],
        2 => [
            "Package_Name" => "Khung việc làm mới nhất:"
        ],
        3 => [
            "Package_Name" => "Khung việc làm hấp dẫn:"
        ],
        4 => [
            "Package_Name" => "Khung việc làm Tuyển gấp"
        ],
        5 => [
            "Package_Name" => "Khung việc làm lương cao:"
        ],
        6 => [
            "Package_Name" => "Khung làm việc cấp quản lý:"
        ],
        7 => [
            "Package_Name" => "Tiêu đề đỏ:"
        ],
        8 => [
            "Package_Name" => "Icon Hot:"
        ],
        9 => [
            "Package_Name" => "Icon Uy tín"
        ],
        10 => [
            "Package_Name" => "Gói lọc hồ sơ:"
        ],
    ];
