
<?php $__env->startSection('title', 'Danh sách nhà tuyển dụng'); ?>
<?php $__env->startSection('css'); ?>
    
    
    <link href="<?php echo e(asset("admin/plugins/datatable/css/jquery.dataTables.min.css")); ?>" rel="stylesheet">
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
    
    <script src="https://cdn.datatables.net/1.10.16/js/jquery.dataTables.min.js"></script>
    
    <script src="//cdn.jsdelivr.net/npm/sweetalert2@10"></script>
    <script>
        
       var table= $('.table').DataTable({
        processing: true,
        serverSide: true,
        ajax: '<?php echo e(route("admin.post.cat.get")); ?>',
        columns: [
            { data: 'Cat_ID',name:'Cat_ID'},
            { data: 'Cat_Title', name: 'Cat_Title'},
            { data: 'Cat_Created_At',name:'Cat_Created_At'},     
            { data:'action',name:'action' }       
        ]
    });

    $(document).on("click",".table .btn-block,.table .btn-delete",function (){
        let url=$(this).attr("data-url");
        Swal.fire({
            title: 'Xóa danh mục',
            text: "Việc xóa danh mục sẽ xóa tất cả bài viết liên quan",
            icon: 'warning',
            showCancelButton: true,
            confirmButtonColor: '#3085d6',
            cancelButtonColor: '#d33',
            confirmButtonText: 'Vẫn tiếp tục'
        }).then((result) => {
        if (result.isConfirmed) {
          window.location.href=url;
            }
        })
        return false;
    })

    $(document).on("click",".box-option .btn-update",function() {
        $("#add-cat.modal-more form,#add-cat.modal-more h5").remove();
        $("#add-cat.modal-more").addClass("show");
        $("#add-cat.modal-more .modal-notification").append('<h5 class="title mb-2 text-dark">Cập nhật danh mục</h5><form method="POST" action="'+$(this).attr("href")+'"> <?php echo csrf_field(); ?> <div class="form-group"><label for="name">Tên danh mục</label><input type="hidden" name="continue" value="<?php echo e(route("admin.post.cat")); ?>"><input type="text" id="name" name="Cat_Title" class="form-control" value="'+$(this).attr("title")+'"></div><div class="form-group my-2"><button class="btn-hero btn-info-hero">Cập nhật</button></div></form>');
        return false;
    })

    $(".btn-add-cat").click(function(){
        $("#add-cat.modal-more form,#add-cat.modal-more h5").remove();
        $("#add-cat.modal-more").addClass("show");
        $("#add-cat.modal-more .modal-notification").append('<h5 class="title mb-2 text-dark">Thêm nhật danh mục</h5><form method="POST" action="<?php echo e(route("admin.post.cat.add")); ?>"> <?php echo csrf_field(); ?> <div class="form-group"><input type="hidden" name="continue" value="<?php echo e(route("admin.post.cat")); ?>"><label for="name">Tên danh mục</label><input type="text" id="name" name="Cat_Title" class="form-control" value=""></div><div class="form-group my-2"><button class="btn-hero btn-info-hero">Thêm</button></div></form>');
    })
    

    $(".btn-exit, .dialog").click(function(){
        $("#add-cat.modal-more form,#add-cat.modal-more h5").remove();
        $("#add-cat.modal-more").removeClass("show");
    })
    
    </script>
<?php $__env->stopSection(); ?>


<?php $__env->startSection('sidebar'); ?>
##parent-placeholder-19bd1503d9bad449304cc6b4e977b74bac6cc771##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?>
##parent-placeholder-594fd1615a341c77829e83ed988f137e1ba96231##
<?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <!--start page wrapper -->
<div class="page-wrapper">
    <div class="page-content">        
        <!--breadcrumb-->
        <div class="page-breadcrumb d-none d-sm-flex align-items-center mb-3">
            <div class="breadcrumb-title pe-3">Cẩm nang</div>
            <div class="ps-3">
                <nav aria-label="breadcrumb">
                    <ol class="breadcrumb mb-0 p-0">
                        <li class="breadcrumb-item"><a href="javascript:;"><i class="bx bx-home-alt"></i></a>
                        </li>
                        <li class="breadcrumb-item active" aria-current="page">Danh mục</li>
                    </ol>
                </nav>
            </div>
            <div class="ms-auto">
                <!-- do not remove block is that -->
            </div>
        </div>
        <!--end breadcrumb-->
        <div class="mx-auto">
            <h6 class="text-uppercase">Danh sách nhà tuyển dụng</h6>
            <div class="box-option pb-4">
                <button class="btn-hero btn-success-hero btn-add-cat"><i class="fas fa-plus"></i></button>
            </div>
           <table class="table table-bordered text-dark vertical-align-middle text-center" style="width: 100%;">
                <thead>
                    <tr>
                        <th>
                            STT
                        </th>
                        <th>
                            Tên Danh mục
                        </th>
                        <th>
                            Ngày tạo
                        </th>
                        <th>
                            Tác vụ
                        </th>
                    </tr>
                </thead>
           </table>
        </div>
        <!--end row-->
    </div>
</div>
<!--end page wrapper -->

<div id="add-cat" class="modal-more">
    <div class="modal-notification modal-lg text-dark">
        <button class="btn-exit btn"><i class="fas fa-times-circle"></i></button>
    </div>
    <div class="dialog"></div>
</div>

<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?><?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.master.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\project_cv\jobber\resources\views/admin/post/indexCat.blade.php ENDPATH**/ ?>