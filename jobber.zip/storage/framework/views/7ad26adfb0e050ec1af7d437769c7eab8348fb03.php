
<?php $__env->startSection("title",$candidate->User_Email); ?>
<?php $__env->startSection("css"); ?>
    
    <link rel="stylesheet" href="<?php echo e(asset("candidate/plugin/dropimage/css/main.css")); ?>">
    <link href="https://unpkg.com/cropperjs/dist/cropper.css" rel="stylesheet" />
    
    <link rel="stylesheet" href="<?php echo e(asset("candidate/plugin/select2/css/select2.min.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("candidate/plugin/select2/css/select2-bootstrap4.css")); ?>">
<?php $__env->stopSection(); ?>
<?php $__env->startSection("js"); ?>


<script src="<?php echo e(asset("candidate/plugin/select2/js/select2.min.js")); ?>"></script>

<link href="https://unpkg.com/cropperjs/dist/cropper.css" rel="stylesheet" />
<script src="https://unpkg.com/dropzone"></script>
<script src="https://unpkg.com/cropperjs"></script>
<script src="<?php echo e(asset("candidate/plugin/dropimage/js/main.js")); ?>"></script>
<script>
// crop avatar 
crop_image({
    id_preview: "preview_avatar",
    model_preview: "#model-upload-avatar",
    btn_drop: "#crop_avatar",
    producted: ".box-avatar img",
    preview_mini: ".preview_avatar_mini",
    input: "#upload-avatar",
    ajax:true,
    url_post:"<?php echo e(route('upload.image')); ?>",
    _token:"<?php echo e(csrf_token()); ?>"
});
// crop cover
crop_image({
    id_preview: "preview_cover",
    model_preview: "#model-upload-cover",
    btn_drop: "#crop_cover",
    producted: ".box-cover-imgage img",
    preview_mini: ".preview_cover_mini",
    input: "#upload-cover",
    ratio: 3.65,
    ajax:true,
    url_post:"<?php echo e(route('upload.image',['cover'=>1])); ?>",
    _token:"<?php echo e(csrf_token()); ?>"
});

$("#btn-upload-cv").change(function(e) {
    $("#model-upload-cv .box-upload-cv #btn-preview-cv").remove();
    if (e.target.files[0].type.indexOf("application/pdf") != -1) {
        let url = URL.createObjectURL(e.target.files[0]);
        $("#model-upload-cv .box-upload-cv").append('<a href="' + url + '" id="btn-preview-cv" target="_black">Xem trước</a>');
    }
})

$(".list-cv .box-option .btn-delete-cv").click(function(e) {
    Swal.fire({
        title: 'Xóa CV',
        text: "Bạn có muốn xóa cv không!",
        icon: 'warning',
        showCancelButton: true,
        confirmButtonColor: '#3085d6',
        cancelButtonColor: '#d33',
        confirmButtonText: 'Xóa'
    }).then((result) => {
        if (result.isConfirmed) {
            Swal.fire(
                'Hoàn thành!',
                'Cv đã được xóa',
                'success'
            )
        }
    })
    return false;
})

$('#Specialize_ID').select2({
        // minimumInputLength: 2,
        tags: true,
        ajax: {
            url: '<?php echo e(route("employer.data.specialize")); ?>',
            type: 'GET',
            dataType: 'json',
            data: function (params) {
                return {Name: params.term};
            },
            processResults: function (data, params) {
                return {results: $.map(data, function (item) {return {text: item.Name,id: item.Specialize_ID,data: item};})
                };
            }
        }
    });

    $('#Province_ID').select2({
        minimumInputLength: 2,
        ajax: {
            url: '<?php echo e(route("employer.data.province")); ?>',
            type: 'GET',
            dataType: 'json',
            data: function (params) {
                return {Province_Name: params.term};
            },
            processResults: function (data, params) {
                return {results: $.map(data, function (item) {return {text: item.Province_Name,id: item.Province_ID,data: item};})
                };
            }
        }
    });
</script>
<?php $__env->stopSection(); ?>
<?php $__env->startSection("content"); ?>
<div class="container pb-3 pt-1">
    <div class="row">
        <div class="box-left box-profile col-md-8">
            <div class="pannel pannel-top">
                <div class="box-profile-basic box-cover-imgage">
                    <?php
                        $url= $candidate->Cover ?: "candidate/imgs/covers/cover-default.jpg"; 
                    ?>
                    <a href="" id="cover-image"><img src="<?php echo e(asset($url)); ?>" alt="" class="thumbnail"></a>
                    <label for="upload-cover" href="" id="btn-upload-image-cover">Cập nhật ảnh bìa</label>
                    <input type="file" name="upload-cover" class="d-none" id="upload-cover">
                </div>
                <div class="box-profile-basic box-avatar">
                    <?php
                        $url=$candidate->Avatar ?:"candidate/imgs/avatars/default.jpg";
                    ?>
                    <div href="" id="avatar">
                        <label for="upload-avatar" id="btn-upload-avatar"><i class="fas fa-file-upload"></i></label>
                        <input type="file" name="upload-avatar" id="upload-avatar" class="d-none">
                        <img src="<?php echo e(asset($url)); ?>" alt="<?php echo e($candidate->Fullname); ?>" id="thumbnail">
                    </div>
                </div>
                <div class="box-profile-basic box-info">
                    <span class="nickname"><?php echo e($candidate->Fullname); ?></span>
                    <span class="job"><?php echo e($candidate->specialize->Name ?? "Chưa Cập Nhật"); ?></span>
                </div>
                <div class="box-profile-basic box-option">
                    <button class="btn-convert-pdf">Tải Pdf</button>
                    <button class="btn-share">Chia sẽ</button>
                    <button class="btn-update-info" data-toggle="modal" data-target="#model-update-profile">Cập nhật</button>
                </div>
            </div>
            <div class="panel panel-body box-profile-details">
                <div id="gender" class="group">
                    <span class="label">Giới tính: </span>
                    <span class="info"><?php if($candidate->Gender!=null): ?><?php echo e(__("user.Gender.{$candidate->Gender}")); ?><?php else: ?> Chưa cập nhật <?php endif; ?></span>
                </div>
                <div id="phone" class="group">
                    <span class="label">Số điện thoại: </span>
                    <span class="info"><?php echo e($candidate->Phone ?? "Chưa Cập Nhật"); ?></span>
                </div>
                <div id="email" class="group">
                    <span class="label">Email liên hệ: </span>
                    <span class="info"><?php echo e($candidate->User_Email ?? "Chưa Cập Nhật"); ?></span>
                </div>
                <div id="address" class="group">
                    <span class="label">Địa chỉ: </span>
                    <span class="info"><?php echo e($candidate->Address ?? "Chưa Cập Nhật"); ?></span>
                </div>
                <div id="birthday" class="group">
                    <span class="label">Ngày sinh: </span>
                    <span class="info"><?php echo e($candidate->Birthday ?? "Chưa Cập Nhật"); ?></span>
                </div>
                <div id="marriage" class="group">
                    <span class="label">Hôn nhân: </span>
                    <span class="info"><?php if($candidate->Marriage!==null): ?> <?php echo e(__("user.Marriage.{$candidate->Marriage}")); ?> <?php else: ?> Chưa Cập Nhật <?php endif; ?></span>
                </div>
                <div id="special" class="group">
                    <span class="label">Ngành: </span>
                    <span class="info"><?php echo e($candidate->specialize->Name ?? "Chưa cập nhật"); ?></span>
                </div>
                <div id="experience" class="group">
                    <span class="label">Kinh nghiệm: </span>
                    <span class="info"><?php if($candidate->Experience): ?> <?php echo e(__("user.Experience.{$candidate->Experience}")); ?> <?php else: ?> Chưa Cập Nhật <?php endif; ?> </span>
                </div>
                <div id="wage" class="group">
                    <span class="label">Mức lương: </span>
                    <span class="info">
                        <?php
                            $wage="Mức lương thỏa thuận";
                            if($candidate->Wage_From || $candidate->Wage_To ){
                                $wage=$candidate->Wage_To ? "Mức lương đến: ".currency($candidate->Wage_To) :"Mức lương từ: ".currency($candidate->Wage_From); 
                            }
                            if($candidate->Wage_From && $candidate->Wage_To ){
                                $wage="Mức lương từ: ".currency($candidate->Wage_From)." Đến ".currency($candidate->Wage_To);
                            }
                        ?>
                        <?php echo e($wage); ?>

                    </span>
                </div>
            </div>
            <div class="box-profile-details">
                <div id="desc" class="group">
                    <span class="label">Mô tả:</span>
                    <span class="info"><?php echo e($candidate->Description ?? "Chưa cập nhật"); ?></span>
                </div>
            </div>
            <div class="box-list-cv">
                <div class="box-top">
                    <h4 class="title">Quản lý cv</h4>
                    <a class="btn-add-cv" data-toggle="modal" data-target="#model-upload-cv" href="">Thêm</a>
                </div>
                <ul class="list-cv">
                    <?php $__currentLoopData = $candidate->cvs; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $cv): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <div class="box-cv">
                            <iframe src="<?php echo e(asset($cv->File)); ?>" width="100%" height="100%" frameborder="0"></iframe>
                        </div>
                        <div class="box-option">
                            <h5 class="title"><?php echo e($cv->Cv_Title); ?></h5>
                            <p class="date-created"><?php echo e($cv->Cv_Created_At); ?></p>
                            <a href="<?php echo e(route("action.cv",["id"=>$cv->Cv_ID,"option"=>$cv->Is_Default ])); ?>" class="btn-set-cv-default <?php if($cv->Is_Default): ?> active <?php endif; ?>">Đặt làm cv mặt định</a>
                            <a href="<?php echo e(asset($cv->File)); ?>" download="Jobber_Cv_<?php echo e($cv->File); ?>" class="btn-download-cv">Tải cv xuống</a>
                            <a href="<?php echo e(asset($cv->File)); ?>" class="btn-seen-cv">Xem cv</a>
                            <a href="<?php echo e(route("action.cv",["id"=>$cv->Cv_ID,"option"=>2])); ?>" class="btn-delete-cv">Xóa Cv</a>
                        </div>
                    </li>      
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>              
                </ul>
            </div>
        </div>
        <div class="box-right box-profile box-status col-md-4">
            <div class="pannel">
                <div class="form-group m-0">
                    <input type="checkbox" id="status" name="status">
                    <label for="status"> Ẩn thông tin profile </label>
                </div>
                <p class="desc">
                    Khi tắt ngày tuyền dụng sẽ không thể xem thông tin profile của bạn
                </p>
            </div>
            <div class="pannel">
                <div class="form-group m-0">
                    <input type="checkbox" id="status" name="status">
                    <label for="status"> Thông báo việc làm </label>
                </div>
                <p class="desc">
                    Bật lên để nhận thông báo công việc phù hợp
                </p>
            </div>
            <div class="pannel statical">
                <span class="title">Ai đó xem thông tin của bạn</span>
                <ul class="list-people-seen">
                <?php if(count($employerSeens)): ?>    
                    <?php $__currentLoopData = $employerSeens; $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $employerSeen): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                    <li>
                        <a href="<?php echo e(route("company.info",$employerSeen->Company_Slug)); ?>" class="employer"><img class="thumbnail" src="<?php echo e(asset($employerSeen->Company_Logo)); ?>" alt="<?php echo e($employerSeen->Company_Name); ?>"></a>
                    </li>
                    <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                <?php else: ?>               
                    <li>Không có nhà tuyển dụng nào xem bạn</li>
                <?php endif; ?>    
                </ul>
            </div>
            <div class="pannel banner-advertisement p-0">
                <a href="" class="banner">
                    <img src="https://fptshop.com.vn/uploads/images/tin-tuc/77581/Originals/IMG_9876.JPG" class="thumbnail" alt="">
                </a>
            </div>
        </div>

    </div>
</div>

<!-- model-update-profile -->
<div class="modal fade" id="model-update-profile" role="dialog" aria-labelledby="model-update-profile" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <form action="<?php echo e(route("info")); ?>" method="POST" class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title" id="exampleModalLabel">Cập nhật thông tin</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body row">
                <?php echo csrf_field(); ?>
                <input type="hidden" name="continue" value="<?php echo e(route("info")); ?>">
                <div class="form-group col-md-4 <?php $__errorArgs = ["Fullname"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="Fullname">Họ và tên: </label>
                    <input type="text" name="Fullname" id="Fullname" class="form-control" value="<?php echo e($candidate->Fullname); ?>">
                    <?php $__errorArgs = ["Fullname"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="message"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-md-4 <?php $__errorArgs = ["Specialize_ID"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="Specialize_ID">Công việc hiện tại: </label>
                    <select name="Specialize_ID" id="Specialize_ID" class="form-control">
                        <option value="<?php echo e($candidate->Specialize_ID); ?>"><?php echo e($candidate->specialize->Name ??""); ?></option>
                    </select>
                    <?php $__errorArgs = ["Specialize_ID"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="message"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-md-4 <?php $__errorArgs = ["Gender"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="Gender">Giới tính: </label>
                    <select name="Gender" class="form-control basic-select" id="Gender">
                       <?php $__currentLoopData = __("user.Gender"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                        <option value="<?php echo e($key); ?>" <?php if($candidate->Gender == $key): ?> selected <?php endif; ?>><?php echo e($item); ?></option>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ["Gender"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="message"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-md-4 <?php $__errorArgs = ["Phone"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="Phone">Số điện thoại: </label>
                    <input type="text" name="Phone" id="Phone" class="form-control" value="<?php echo e(old("Phone") ?? $candidate->Phone); ?>">
                    <?php $__errorArgs = ["Phone"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="message"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-md-4 <?php $__errorArgs = ["User_Email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="User_Email">Email: </label>
                    <input type="text" name="User_Email" id="User_Email" class="form-control" value="<?php echo e(old("User_Email") ?? $candidate->User_Email); ?>">
                    <?php $__errorArgs = ["User_Email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="message"><?php echo e($message); ?></span>                    
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-md-4 <?php $__errorArgs = ["Marriage"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="Marriage">Hôn nhân: </label>
                    <select name="Marriage" class="form-control" id="Marriage">
                       <?php $__currentLoopData = __("user.Marriage"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key => $item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>" <?php if($candidate->Marriage == $key): ?> selected <?php endif; ?>><?php echo e($item); ?></option>
                       <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                    <?php $__errorArgs = ["Marriage"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="message"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                <div class="form-group col-md-4">
                    <label for="Birthday">Ngày sinh: </label>
                    <input type="date" name="Birthday" id="Birthday" value="<?php echo e(old("Birthday") ?? $candidate->Birthday); ?>" class="form-control">
                </div>
                <div class="form-group col-md-4">
                    <label for="Province_ID">Khu vực thông báo: </label>
                    <select name="Province_ID" class="form-control" id="Province_ID">
                        <option value="<?php echo e($candidate->Province_ID); ?>"><?php echo e($candidate->province->Province_Name ?? ""); ?></option>
                    </select>
                </div>
                <div class="form-group col-md-4">
                    <label for="Experience">Kinh nghiệm: </label>
                    <select name="Experience" class="form-control basic-select" id="Experience">
                        <?php $__currentLoopData = __("user.Experience"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>" <?php if($candidate->Experience==$key): ?> selected <?php endif; ?>><?php echo e($item); ?></option>
                        <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                    </select>
                </div>
                <div class="form-group col-md-4 <?php $__errorArgs = ["Wage_From"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="Wage_From">Mức lương từ: </label>
                    <input type="text" class="form-control" id="Wage_From" name="Wage_From" value="<?php echo e(old("Wage_From") ?? $candidate->Wage_From); ?>">
                    <?php $__errorArgs = ["Wage_From"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="message"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                </div>
                 <div class="form-group col-md-4 <?php $__errorArgs = ["Wage_To"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                    <label for="Wage_To">Mức lương đến: </label>
                    <input type="text" class="form-control" name="Wage_To" id="Wage_To" value="<?php echo e(old("Wage_To") ?? $candidate->Wage_To); ?>">
                    <?php $__errorArgs = ["Wage_To"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <span class="message"><?php echo e($message); ?></span>
                    <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                 </div>
                <div class="form-group col-md-12">
                    <label for="Address">Địa chỉ: </label>
                    <textarea type="text" name="Address" id="Address" cols="10" rows="5" class="form-control"><?php echo e($candidate->Address); ?></textarea>
                </div>
                <div class="form-group col-md-12">
                    <label for="Description">Mô tả: </label>
                    <textarea type="text" name="Description" id="Description" cols="10" rows="5" class="form-control"><?php echo e($candidate->Description); ?></textarea>
                </div>

            </div>
            <div class="modal-footer">
                <button class="btn btn-primary">Lưu</button>
            </div>
        </form>
    </div>
</div>

<!-- model upload avatar -->
<div class="modal fade" id="model-upload-avatar" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Chỉnh sửa avatar</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="img-container">
                    <div class="row">
                        <div class="col-md-8">
                            <img src="" id="preview_avatar" />
                        </div>
                        <div class="col-md-4">
                            <div class="preview_avatar_mini">

                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" id="crop_avatar" class="btn btn-primary">Lưu</button>
            </div>
        </div>
    </div>
</div>

<!-- model upload cover -->
<div class="modal fade" id="model-upload-cover" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Chỉnh sửa avatar</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="img-container">
                    <div class="row">
                        <div class="col-md-8">
                            <img src="" id="preview_cover" />
                        </div>
                        <div class="col-md-4">
                            <div class="preview_cover_mini">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" id="crop_cover" class="btn btn-primary">Lưu</button>
            </div>
        </div>
    </div>
</div>

<!-- model upload cv -->
<div class="modal fade" id="model-upload-cv" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <form action="<?php echo e(route("upload.cv")); ?>" class="modal-content" method="POST" enctype="multipart/form-data">
            <?php echo csrf_field(); ?>
            <div class="modal-header">
                <h5 class="modal-title">Upload Cv của bạn</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <input type="hidden" name="continue" value="<?php echo e(route("info")); ?>">
            <div class="modal-body">
                <div class="form-group">
                    <label for="cv-title">Tiêu đề cv</label>
                    <input type="text" class="form-control" name="Cv_Title" id="cv-title">
                </div>
                <div class="form-group box-upload-cv">
                    <label for="btn-upload-cv">Tải cv(pdf): </label>
                    <input type="file" name="cv" class="d-none" id="btn-upload-cv">
                </div>
            </div>
            <div class="modal-footer">
                <button id="btn-upload-cv" class="btn btn-primary">Lưu</button>
            </div>
        </form>
    </div>
</div>
<?php $__env->stopSection(); ?>

<?php echo $__env->make("candidate.master.index", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\project_cv\jobber\resources\views/candidate/user/info.blade.php ENDPATH**/ ?>