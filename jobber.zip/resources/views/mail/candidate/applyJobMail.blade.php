<table border="0" cellpadding="0" cellspacing="0" width="100%">
    <tbody>
        <tr>
            <td align="center" bgcolor="#f3f3f3" valign="top" style="background:#f3f3f3;color:#000000;padding:20px 0px">
                <h1 style="margin:0">
                    <a href="http://email.tuyendungtopcv.com/c/eJw9jUEOgyAURE8jS_IBsbpgUZt4DQN8UFsBY9HE25e0SZOZTDKL91D51jLTkUVx4AwELwOMc8ooE7VsAHrZd0NzE4-qhnxcLuIRp5w2e1KbApkVemHQ1KVSg26gEw51y732qCXalqxqznl7V-Je8aHkT6E_zBnLSXb1mo8Up3CxYpqCXtavICsXtjVdbh-fyYy7ezqbHX4ACfo7uQ" alt="topcv.vn" target="_blank" data-saferedirecturl="https://www.google.com/url?q=http://email.tuyendungtopcv.com/c/eJw9jUEOgyAURE8jS_IBsbpgUZt4DQN8UFsBY9HE25e0SZOZTDKL91D51jLTkUVx4AwELwOMc8ooE7VsAHrZd0NzE4-qhnxcLuIRp5w2e1KbApkVemHQ1KVSg26gEw51y732qCXalqxqznl7V-Je8aHkT6E_zBnLSXb1mo8Up3CxYpqCXtavICsXtjVdbh-fyYy7ezqbHX4ACfo7uQ&amp;source=gmail&amp;ust=1618506849447000&amp;usg=AFQjCNFZ2D50DZsKJhxdz2q8WFqbUWm-nw">
                        <img src="https://ci5.googleusercontent.com/proxy/wjZz3CR_oBr1yo5qEVeCWW8WtKcfnzj9y8llT-fRT01_iQoTt5MoI458AaNVWMrqwbKEs0qcFb8Iw4YSE84Kig87ynTZwLs1Xuh_=s0-d-e1-ft#https://topworking.vn/images/topcv_epl_business_logo.png" width="100" alt="topcv.vn" style="border:0" class="CToWUd">
                    </a>
                </h1>
            </td>
        </tr>
        <tr>
            <td align="center" bgcolor="#f3f3f3">
                <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:600px;padding:0px 10px">
                    <tbody>
                        <tr>
                            <td>
                            </td>
                        </tr>
                        <tr>
                            <td style="padding:20px;border-bottom:2px solid #dddddd" bgcolor="#ffffff">
                            <p>
                                <strong>Ứng viên {{ $data["Fullname"] }}</strong>
                                Đã Ứng tuyển vào công việc {{ $data["Job_Title"] }} của bạn vui lòng kiểm tra
                            </p>
                                <ul>
                                    <li><strong><em>Hotline CSKH: </em></strong></li>
                                    <li style="display:initial;padding-left:100px"><strong><em></em></strong></li>
                                    <li><strong><em>Email: <a href="mailto:cskh@topcv.vn" target="_blank">cskh@<span class="il">topcv</span>.vn</a></em></strong></li>
                                </ul>
                                <p>Trân trọng,</p>
                                <p>Phòng Dịch vụ Khách hàng - <span class="il">TOPCV</span></p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>


        <tr>
            <td align="center">
                <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:600px">
                    <tbody>
                        <tr>
                            <td style="padding:0px 10px">
                                <a href="http://email.tuyendungtopcv.com/c/eJw9jcsKgzAURL_GLENy86gusqgFf0NiHmprHtgo-PcNLRQGhpnFOVb51tCpQ6sCApQwqEUoAKaYMi4kIb3ou0He2KPhpByXi_aIc0nZnNikgBblQTLSWvCaC8-4nyZSJ7dSCG0sOLSppZT8bti9gaHmT8E_zBnrqXNGu3otR4pzuGiVzUGv29dRlAt5S5fbx2eaxt09nSnOfgBLozvf" target="_blank" data-saferedirecturl="https://www.google.com/url?q=http://email.tuyendungtopcv.com/c/eJw9jcsKgzAURL_GLENy86gusqgFf0NiHmprHtgo-PcNLRQGhpnFOVb51tCpQ6sCApQwqEUoAKaYMi4kIb3ou0He2KPhpByXi_aIc0nZnNikgBblQTLSWvCaC8-4nyZSJ7dSCG0sOLSppZT8bti9gaHmT8E_zBnrqXNGu3otR4pzuGiVzUGv29dRlAt5S5fbx2eaxt09nSnOfgBLozvf&amp;source=gmail&amp;ust=1618506849447000&amp;usg=AFQjCNGb_mlK4X-Lumh74ZbWsj0gxvHk2Q">
                                    <img style="width:100%" src="https://ci5.googleusercontent.com/proxy/mg0fHeoxpLgc7woYJVk1JsE1GIgqh-0o8vBTzYzAwnOMBLsHhxxFJ_DF8Z60rviQLpTvYgLiFDEsz8wyogjiUvRDyTlWx1g6t-IpmVBh=s0-d-e1-ft#http://static.topcv.vn/manual/banner-tai-app-epl-footer.jpg" class="CToWUd">
                                </a>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>
        <tr>
            <td align="center">
                <span style="text-align:center;color:#f73d3d;font-size:0.9em">Chú ý: Đây là email tự động từ dịch vụ <span class="il">TopCV</span>.vn. Vui lòng không trả lời lại email này!</span><br>
                <table border="0" cellpadding="0" cellspacing="0" width="100%" style="max-width:600px">
                    <tbody>
                        <tr>
                            <td style="padding:20px;font-size:12px;color:#888;text-align:center" bgcolor="#f3f3f3" align="center">
                                <p>
                                    <a href="http://email.tuyendungtopcv.com/c/eJwljcsKgzAQRb_GLGXy0maRRS34G6KT8a0RGxX_vmkLFw7cxTnOtg_kjWGDFSA4SBEBXIiUp1wqnQEUujBllstXoiAcN63uWLvgNzxT9AvrLUjDnau1MwhASqNWGozilAlEyh2bbR_C9k7kMxFl3HVdaVsjNd5PX0e8_r5zZbud-sOv3XLz2OuWeph_mWBp2WZ_016Nvql2GgkDuQ_JSDxp" style="margin:0px 5px" target="_blank" data-saferedirecturl="https://www.google.com/url?q=http://email.tuyendungtopcv.com/c/eJwljcsKgzAQRb_GLGXy0maRRS34G6KT8a0RGxX_vmkLFw7cxTnOtg_kjWGDFSA4SBEBXIiUp1wqnQEUujBllstXoiAcN63uWLvgNzxT9AvrLUjDnau1MwhASqNWGozilAlEyh2bbR_C9k7kMxFl3HVdaVsjNd5PX0e8_r5zZbud-sOv3XLz2OuWeph_mWBp2WZ_016Nvql2GgkDuQ_JSDxp&amp;source=gmail&amp;ust=1618506849448000&amp;usg=AFQjCNEDH0mxD263HFhE4KAq0e2WbaY89w"><img src="https://ci4.googleusercontent.com/proxy/Bm25w2ToKcqgKwh982U6SwEaZxM5zx0unK1-SU0PNH5hJ6MJlS1NsDmCbtiUUsJSzgX-MEbrrYGZRTLN_c9pMQD7MVPIvyEUtIPC=s0-d-e1-ft#https://www.topcv.vn/images/emails/color-facebook-48.png" height="24" width="24" class="CToWUd"></a>
                                    <a href="http://email.tuyendungtopcv.com/c/eJwdjcsKgzAURL9Gl3ITjU0WWVTBLyhuJTHXV40Re23x75sWZhjOYjhOD7JnVqWz5sAZ5DwOMM4zlrG8ECVAJSrVlLe8Tgqg88LNndtIYe_fWR98OmlunYx1zAxcWIUgFTgDRkphhXIuXfVEtL-S_J7wJoY-MxEev3ukR9jrtp2RNuPTQz-nM2yjv1jUjd7M699CGv2-hguPbgm2O3DBntB9AdF-PKU" style="margin:0px 5px" target="_blank" data-saferedirecturl="https://www.google.com/url?q=http://email.tuyendungtopcv.com/c/eJwdjcsKgzAURL9Gl3ITjU0WWVTBLyhuJTHXV40Re23x75sWZhjOYjhOD7JnVqWz5sAZ5DwOMM4zlrG8ECVAJSrVlLe8Tgqg88LNndtIYe_fWR98OmlunYx1zAxcWIUgFTgDRkphhXIuXfVEtL-S_J7wJoY-MxEev3ukR9jrtp2RNuPTQz-nM2yjv1jUjd7M699CGv2-hguPbgm2O3DBntB9AdF-PKU&amp;source=gmail&amp;ust=1618506849448000&amp;usg=AFQjCNH3MYlunEPiys66220aBnT34vy0Cg"><img src="https://ci3.googleusercontent.com/proxy/bldm1k7lCYbBNJ_o4rIFAatPYRCc_McZXGXPmw9X7IgTnKSn6KFK7XOoK7nymCreqyvbarkBgUDiav27bWoIc9QBIOS3wMSs2XE=s0-d-e1-ft#https://www.topcv.vn/images/emails/color-twitter-48.png" height="24" width="24" class="CToWUd"></a>
                                    <a href="http://email.tuyendungtopcv.com/c/eJwljdsKgzAQRL_GPMruJkZ9yEMt-BtiYuqlJhEbFf--oYWBgYFzZlCvyqCu2awICIFTKkCiHHPkopAATdHUrSz5MxMQj9v64fBjDJs5cxMcmxRqA4WUCeU1YGWrUlOvSykkibQhW9UU4_bJ-COjNuW6rvwvOD3b1Xs6gh_djelgdP28_rxRWbet4bZ7twTd7XaxJtrhCxIRNf0" style="margin:0px 5px" target="_blank" data-saferedirecturl="https://www.google.com/url?q=http://email.tuyendungtopcv.com/c/eJwljdsKgzAQRL_GPMruJkZ9yEMt-BtiYuqlJhEbFf--oYWBgYFzZlCvyqCu2awICIFTKkCiHHPkopAATdHUrSz5MxMQj9v64fBjDJs5cxMcmxRqA4WUCeU1YGWrUlOvSykkibQhW9UU4_bJ-COjNuW6rvwvOD3b1Xs6gh_djelgdP28_rxRWbet4bZ7twTd7XaxJtrhCxIRNf0&amp;source=gmail&amp;ust=1618506849448000&amp;usg=AFQjCNFqQZGDZLsfx5u4AC23V4otqiHgzQ"><img src="https://ci3.googleusercontent.com/proxy/JwlnTXph5J5te3fjznpG94vnuP6D3YmsqKvxg4sphmCIYa6J3eApYzVvOgdw37fQ41FH34pentZd_d6iiuS5ElwQiHkPc54=s0-d-e1-ft#https://www.topcv.vn/images/emails/color-link-48.png" height="24" width="24" class="CToWUd"></a>
                                </p>
                                <p>Copyright © 2016 <a href="http://email.tuyendungtopcv.com/c/eJwljMkKgzAURb_GLOXlZaqLLGrB3xAzONUkYqPg3ze0cOCezT1Ojw9LTUMWjYAUGJYBiljTmjIuJEAr2qaTir0qDvm8fXRnnHLa7VXbFMisbQMGB45SCK6UAWV4o5R3KNhIJVKy6Tnn_VOxZ4Vd4X--YlFy6Pd8pjiFm5b-FIZl-2Wz9mHf0u2Pfk2mP_zqbfbuC-YNNXY" title="Quản lý CV" style="color:#888;text-decoration:underline" target="_blank" data-saferedirecturl="https://www.google.com/url?q=http://email.tuyendungtopcv.com/c/eJwljMkKgzAURb_GLOXlZaqLLGrB3xAzONUkYqPg3ze0cOCezT1Ojw9LTUMWjYAUGJYBiljTmjIuJEAr2qaTir0qDvm8fXRnnHLa7VXbFMisbQMGB45SCK6UAWV4o5R3KNhIJVKy6Tnn_VOxZ4Vd4X--YlFy6Pd8pjiFm5b-FIZl-2Wz9mHf0u2Pfk2mP_zqbfbuC-YNNXY&amp;source=gmail&amp;ust=1618506849532000&amp;usg=AFQjCNEvSEUulx0t68jnpyWmusp_HyrSmA"><span class="il">TopCV</span></a>, All rights reserved.</p>
                                <p>
                                    <a href="http://email.tuyendungtopcv.com/c/eJwljUEOgyAUBU-juxo-qOCCRW3iNYzAF2gFjEGNt69pk0leZvEyRs5Cg-pKLymhQBi9hwClFVTA6qYlpG_6bmg5exU1yfuF0ezR5rTqo9IplE52SmijOfIGVKtqPSGKmQMKNIbh3JSLdDmvBXsWdLg5z7P6_494q_XJP7LzuJeb_Lg9RRsuuGM2TH75NbLEsC7pwm18JzVu-Ead0XwBkmo8fQ" style="color:#888;display:inline-block;margin:0px 10px;text-decoration:underline" target="_blank" data-saferedirecturl="https://www.google.com/url?q=http://email.tuyendungtopcv.com/c/eJwljUEOgyAUBU-juxo-qOCCRW3iNYzAF2gFjEGNt69pk0leZvEyRs5Cg-pKLymhQBi9hwClFVTA6qYlpG_6bmg5exU1yfuF0ezR5rTqo9IplE52SmijOfIGVKtqPSGKmQMKNIbh3JSLdDmvBXsWdLg5z7P6_494q_XJP7LzuJeb_Lg9RRsuuGM2TH75NbLEsC7pwm18JzVu-Ead0XwBkmo8fQ&amp;source=gmail&amp;ust=1618506849532000&amp;usg=AFQjCNE5iRNRt_5c7Xz45n9Zj9qBi2r4Ug">Giới thiệu</a>
                                    <a href="mailto:partner@topcv.vn" style="color:#888;display:inline-block;margin:0px 10px;text-decoration:underline" target="_blank">Hợp tác</a>
                                    <a href="http://email.tuyendungtopcv.com/c/eJwlzUsOgyAYBODTyJLAjygsWNQmXsMAUtTyMBZNvH1Jm0wymc03s3oJS41EqwIClDCoRSgAppiylneEDHyQY9ezZ9OSct4uzWfyJe_2wjZHtCgO0Aupue1bJog2xljnhGS6UlwLjYJaStk_DXs0MNaYkD3-C1eqGx3qvZw5-XjTeuKjXsPPLsrFPeTbHdOWzXS4zdni5i804zgC" style="color:#888;display:inline-block;margin:0px 10px;text-decoration:underline" target="_blank" data-saferedirecturl="https://www.google.com/url?q=http://email.tuyendungtopcv.com/c/eJwlzUsOgyAYBODTyJLAjygsWNQmXsMAUtTyMBZNvH1Jm0wymc03s3oJS41EqwIClDCoRSgAppiylneEDHyQY9ezZ9OSct4uzWfyJe_2wjZHtCgO0Aupue1bJog2xljnhGS6UlwLjYJaStk_DXs0MNaYkD3-C1eqGx3qvZw5-XjTeuKjXsPPLsrFPeTbHdOWzXS4zdni5i804zgC&amp;source=gmail&amp;ust=1618506849532000&amp;usg=AFQjCNG7VXMConhfzBcQS3e3li_Kz44x7A">Blog</a>
                                </p>
                            </td>
                        </tr>
                    </tbody>
                </table>
            </td>
        </tr>

    </tbody>
</table>