<?php if(session('employer')): ?>

<header class="header bg-dark">
    <nav class="navbar navbar-static-top navbar-expand-lg header-sticky">
        <div class="container-fluid">
            <button id="nav-icon4" type="button" class="navbar-toggler" data-toggle="collapse" data-target=".navbar-collapse">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <a class="navbar-brand" href="<?php echo e(route("employer.home")); ?>">
                <img class="img-fluid" src="<?php echo e(asset("employer/img/logo.svg")); ?>" alt="logo">
            </a>
            <div class="navbar-collapse collapse justify-content-start">
                <ul class="nav navbar-nav">
                    <li class="nav-item dropdown <?php echo e(setMenuActive("employer.home","employer")); ?>">
                        <a class="nav-link" href="<?php echo e(route("employer.home")); ?>" id="navbarDropdown">Trang chủ</a>
                    </li>
                    <li class="nav-item dropdown <?php echo e(setMenuActive("employer.dashboard","employer")); ?>">
                        <a class="nav-link" href="<?php echo e(route("employer.dashboard")); ?>" id="navbarDropdown">Dashboard</a>
                    </li>
                    <li class="nav-item dropdown <?php echo e(setMenuActive("employer.job","employer")); ?> <?php echo e(setMenuActive("employer.job.add","employer")); ?>">
                        <a class="nav-link dropdown-toggle" href="javascript:void(0)" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Tuyển dụng <i class="fas fa-chevron-down fa-xs"></i>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="<?php echo e(route("employer.job.add")); ?> ">Đăng bài</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route("employer.job")); ?>">Danh sách tin tuyển dụng</a></li>
                        </ul>
                    </li>
                    <li class="dropdown nav-item <?php echo e(setMenuActive("employer.candidate","employer")); ?> <?php echo e(setMenuActive("employer.candidate.save","employer")); ?>">
                        <a href="javascript:void(0)" class="nav-link" data-toggle="dropdown">Ứng viên<i class="fas fa-chevron-down fa-xs"></i></a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="<?php echo e(route("employer.candidate")); ?>">Ứng viên</a></li>
                            <li><a class="dropdown-item" href="<?php echo e(route("employer.candidate.save")); ?>">Hồ sơ đã lưu</a></li>
                        </ul>
                    </li>
                    <li class="nav-item dropdown <?php echo e(setMenuActive("employer.product.buy","employer")); ?> ">
                        <a class="nav-link dropdown-toggle" href="javascript:void(0)" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                            Dịch vụ<i class="fas fa-chevron-down fa-xs"></i>
                        </a>
                        <ul class="dropdown-menu">
                            <li><a class="dropdown-item" href="<?php echo e(route("employer.product.buy")); ?>">Mua gói dịch vụ</a></li>
                            <li><a class="dropdown-item" href="employer-grid.html">Danh sách đơn hơn</a></li>
                        </ul>
                    </li>
                    <li class="dropdown nav-item">
                        <a href="<?php echo e(route("post")); ?>" class="nav-link">Bài viết</a>
                    </li>
                </ul>
            </div>
            <div class="add-listing d-flex align-items-sm-center pr-3">
                <div class="box-avatar dropdown d-inline-block mr-4">
                    <a href="" id="dropdown-profile" class="box-thumbnail dropdown-toggle" data-toggle="dropdown" aria-haspopup="true" aria-expanded="false">
                        <?php
                            $url="employer/img/avatars/default-".session("employer.Gender").".jpg";
                            if(!empty(session("employer.Avatar"))){
                                $url=session("employer.Avatar");
                            }
                        ?>
                        <img class="thumbnail img-fluid" src="<?php echo e(asset($url)); ?>" alt="">
                    </a>
                    <div class="dropdown-menu text-center" aria-labelledby="dropdown-profile">
                        <a class="dropdown-item btn-info" href="<?php echo e(route("employer.info")); ?>"><?php echo e(session("employer.Fullname")); ?></a>
                        <a class="dropdown-item btn-info-company" href="<?php echo e(route("employer.company.info")); ?>">Thông tin công ty</a>
                        <a class="dropdown-item btn-history" href="<?php echo e(route("employer.history")); ?>">Lịch sử hoạt động</a>
                        <a class="btn btn-danger" href="<?php echo e(route("employer.logout")); ?>">Đăng xuất</a>
                    </div>
                </div>
                <div class="box-ring position-relative">
                    <span class="number">10</span>
                    <a href="<?php echo e(route("employer.history")); ?>" id="btn-notification"><i class="far fa-bell"></i></a>
                </div>
            </div>
        </div>
    </nav>
</header>
<?php else: ?>

<header class="header bg-dark">
    <nav class="navbar navbar-static-top navbar-expand-lg header-sticky">
        <div class="container-fluid">
            <button id="nav-icon4" type="button" class="navbar-toggler" data-toggle="collapse" data-target=".navbar-collapse">
                <span></span>
                <span></span>
                <span></span>
            </button>
            <a href="<?php echo e(route("employer.home")); ?>" class="navbar-brand" href="index.html">
                <img class="img-fluid" src="<?php echo e(asset("employer/img/logo.svg")); ?>" alt="logo">
            </a>
            <div class="navbar-collapse collapse justify-content-start">
                <ul class="nav navbar-nav">
                    <li class="nav-item dropdown active">
                        <a class="nav-link" href="#" id="navbarDropdown">Trang chủ</a>
                    </li>
                    <li class="dropdown nav-item">
                        <a href="<?php echo e(route("post")); ?>" class="nav-link">Bài viết</a>
                    </li>
                </ul>
            </div>
            <div class="add-listing">
                <div class="login d-inline-block mr-4">
                    <a href="login.html" id="btn-login" data-toggle="modal" data-target=".model-login"><i class="far fa-user pr-2"></i>Đăng nhập</a>
                </div>
            </div>
        </div>
    </nav>
</header>
<?php endif; ?><?php /**PATH C:\xampp\htdocs\laravel\project_cv\jobber\resources\views/employer/include/header.blade.php ENDPATH**/ ?>