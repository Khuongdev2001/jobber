
<?php $__env->startSection('title', 'Trang đăng nhập'); ?>
<?php $__env->startSection('css'); ?>
    
<?php $__env->stopSection(); ?>

<?php $__env->startSection('js'); ?>
    
    <script>
			(function () {
			  'use strict'	
			  var forms = document.querySelectorAll('.needs-validation')	
			  // Loop over them and prevent submission
			  Array.prototype.slice.call(forms)
				.forEach(function (form) {
				  form.addEventListener('submit', function (event) {
					if (!form.checkValidity()) {
					  event.preventDefault()
					  event.stopPropagation()
					}	
					form.classList.add('was-validated')
				  }, false)
				})
			})()
	</script>

<?php $__env->stopSection(); ?>


<?php $__env->startSection('sidebar'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('header'); ?><?php $__env->stopSection(); ?>

<?php $__env->startSection('content'); ?>
    <div class="section-authentication-signin d-flex align-items-center justify-content-center my-5 my-lg-0">
        <div class="container-fluid">
            <div class="row row-cols-1 row-cols-lg-2 row-cols-xl-3">
                <div class="col mx-auto">
                    <div class="card">
                        <div class="card-body">
                            <div class="border p-4 rounded">
                                <div class="text-center">
                                    <h3 class="">Jobber Login</h3>
                                </div>
                                <div class="form-body">
                                    <form class="row g-3" action="<?php echo e(route("admin.user.login")); ?>" method="POST">
                                        <?php echo csrf_field(); ?>
                                        <div class="col-12">
                                            <label for="User_Email" class="form-label">Email:</label>
                                            <input type="email" class="form-control needs-validation" id="User_Email" name="User_Email" value="<?php echo e(old("User_Email")); ?>" placeholder="Nhập địa chỉ Email... ">
                                        </div>
                                        <div class="col-12">
                                            <label for="User_Password" class="form-label">Mật khẩu:</label>
                                            <div class="input-group" id="User_Password">
                                                <input type="password" class="form-control border-end-0 needs-validation" id="User_Password" name="User_Password" value="<?php echo e(old("User_Password")); ?>" placeholder="Nhập Mật khẩu... ">
                                                <a href="javascript:;" class="input-group-text bg-transparent"><i class='bx bx-hide'></i></a>
                                            </div>
                                        </div>
                                        <div class="col-12">
                                            <div class="d-grid">
                                                <button type="submit" class="btn btn-light"><i class="bx bxs-lock-open"></i>Đăng nhập</button>
                                            </div>
                                        </div>
                                    </form>
                                </div>
                            </div>
                        </div>
                    </div>
                </div>
            </div>
        </div>
    </div>
<?php $__env->stopSection(); ?>

<?php $__env->startSection('footer'); ?><?php $__env->stopSection(); ?>

<?php echo $__env->make("admin.master.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\project_cv\jobber\resources\views/admin/user/login.blade.php ENDPATH**/ ?>