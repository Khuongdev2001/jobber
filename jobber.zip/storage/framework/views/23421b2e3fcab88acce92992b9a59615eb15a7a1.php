
<?php $__env->startSection("title","Xin chào {$employer->Fullname}"); ?>
<?php $__env->startSection("css"); ?>
    
    <link rel="stylesheet" href="<?php echo e(asset("employer/plugins/dropimage/css/main.css")); ?>">
    <link href="https://unpkg.com/cropperjs/dist/cropper.css" rel="stylesheet" />
    
    <link rel="stylesheet" href="<?php echo e(asset("admin/plugins/select2/css/select2.min.css")); ?>">
    <link rel="stylesheet" href="<?php echo e(asset("admin/plugins/select2/css/select2-bootstrap4.css")); ?>">
<?php $__env->stopSection(); ?>

<?php $__env->startSection("js"); ?>
    <script src="https://unpkg.com/dropzone"></script>
    <script src="https://unpkg.com/cropperjs"></script>
    <script src="<?php echo e(asset("employer/plugins/dropimage/js/main.js")); ?>"></script>
    
    <script src="<?php echo e(asset("admin/plugins/select2/js/select2.min.js")); ?>"></script>
    <script>
        $('#Specialize_ID').select2({
        minimumInputLength: 2,
        ajax: {
            url: '<?php echo e(route("employer.data.specialize")); ?>',
            type: 'GET',
            dataType: 'json',
            data: function (params) {
                return {Name: params.term};
            },
            processResults: function (data, params) {
                return {results: $.map(data, function (item) {return {text: item.Name,id: item.Specialize_ID,data: item};})
                };
            }
        }
    });
    
    $(".btn-upload").click(function(){
        $("#upload-file").trigger("click");
    })
	crop_image({
		id_preview: "preview_avatar",
		model_preview: "#modal-upload-avatar",
		btn_drop: "#crop_avatar",
		producted: ".box-thumbnail .thumbnail",
		preview_mini: "#modal-upload-avatar .preview_avatar_mini",
		input: "#upload-file",
        url_post:"<?php echo e(route('employer.upload')); ?>",
        _token:"<?php echo e(csrf_token()); ?>",
        ajax:true
	});
    </script>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("header"); ?>
    <?php echo $__env->make("employer.include.header", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?>
<?php $__env->stopSection(); ?>

<?php $__env->startSection("content"); ?>
<div class="container">
    <div class="row">
        <div class="box-profile-employer col-md-8">
            <h2 class="title text-center">Thông tin chi tiết</h2>
            <nav class="box-top-controll">
                <ul class="box-option list-unstyled d-flex">
                    <li>
                        <a href="javascript:void(0)" class="active" id="label-info-employer">Nhà tuyển dụng</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route("employer.company.info")); ?>" class="" id="label-info-company">Công ty</a>
                    </li>
                    <li>
                        <a href="<?php echo e(route("employer.history")); ?>" class="" id="label-history">Lịch sử hoạt động</a>
                    </li>
                </ul>
            </nav>
            <div class="box-info">
                <ul class="list-info list-unstyled ">
                    <li id="avatar" class="d-flex align-items-center justify-content-between flex-wrap">
                        <?php
                            $url=asset("employer/img/avatars/default-{$employer->Gender}.jpg");
                            if($employer->Avatar){
                                $url=asset($employer->Avatar);
                            };
                        ?>
                        <a href="javascript:void(0)" class="box-thumbnail">
                            <button class="btn-upload"><i class="fas fa-cloud-upload-alt"></i></button>
                            <input type="file" name="" class="d-none" id="upload-file">
                            <img class="thumbnail img-fluid" src="<?php echo e($url); ?>" alt="">
                        </a>
                        <div class="box-option-other">
                            <button id="btn-model-update-profile" data-toggle="modal" data-target=".model-update-employer" class="btn btn-info">Cập nhật</button>
                            <button id="btn-model-repass" data-toggle="modal" data-target=".model-repass" class="btn btn-success">Đổi mật khẩu</button>
                        </div>
                    </li>
                    <li id="fullname">
                        <span class="label">Họ và tên:</span>
                        <span class="value"><?php echo e($employer->Fullname); ?></span>
                    </li>

                    <li id="age">
                        <span class="label">Giới tính:</span>
                        <span class="value"><?php echo e(__("user.Gender.{$employer->Gender}")); ?></span>
                    </li>

                    <li id="phone">
                        <span class="label">Số điện thoại:</span>
                        <span class="value"><?php echo e($employer->Phone ?? "Chưa cập nhật"); ?></span>
                    </li>

                    <li id="service">
                        <span class="label">Chức vụ:</span>
                        <span class="value"><?php if($employer->Regency): ?><?php echo e(__("user.Regency.{$employer->Regency}")); ?> <?php else: ?> Chưa cập nhật <?php endif; ?></span>
                    </li>

                    <li id="email">
                        <span class="label">Email:</span>
                        <span class="value"><?php echo e($employer->User_Email ?? "Chưa cập nhật"); ?></span>
                    </li>

                </ul>
            </div>
        </div>
        <div class="col-md-4 align-self-center">
            <a href=""><img class="img-fluid" src="https://www.aviva.com.vn/Data/Sites/1/media/aviva-vietnam_photo.jpg" alt=""></a>
        </div>
    </div>

</div>


<!-- modal update profile employer -->

<div class="modal fade model-update-employer" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header p-4">
                <h4 class="mb-0 text-center">Tác vụ</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route("employer.update")); ?>" class="row" id="form-update-emplyer" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="continue" value="<?php echo e(route("employer.info")); ?>">
                    <h5 class="title pb-4 col-12">Thông tin nhà tuyển dụng</h5>
                    <div class="form-group col-md-12 <?php $__errorArgs = ["Fullname"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="Fullname">Họ và tên: *</label> 
                        <input type="text" id="Fullname" class="form-control" name="Fullname" value="<?php echo e(old("Fullname") ?? $employer->Fullname); ?>">
                        <?php $__errorArgs = ["Fullname"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <small class="message"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group col-md-12 <?php $__errorArgs = ["User_Email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="User_Email">Email: *</label>
                        <input type="text" id="User_Email" class="form-control" name="User_Email" value="<?php echo e(old("User_Email") ?? $employer->User_Email); ?>">
                        <small class="note font-italic">Jobber khuyến nghị đăng ký bằng email công ty (theo tên miền website công ty) để được hỗ trợ duyệt tin nhanh & đăng tin không giới hạn.</small>
                        <?php $__errorArgs = ["User_Email"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="message"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group col-md-4 <?php $__errorArgs = ["Phone"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="Phone">Số điện thoại</label>
                        <input type="text" id="Phone" class="form-control" name="Phone" value="<?php echo e(old("Phone") ?? $employer->Phone); ?>">
                        <?php $__errorArgs = ["Phone"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="message"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <!-- service -->
                    <div class="form-group col-md-4">
                        <label for="service">Chức vụ: </label>
                        <select type="text" name="Regency" class="form-control <?php $__errorArgs = ["Regency"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>" id="Regency">
                            <?php $__currentLoopData = __("user.Regency"); $__env->addLoop($__currentLoopData); foreach($__currentLoopData as $key=>$item): $__env->incrementLoopIndices(); $loop = $__env->getLastLoop(); ?>
                            <option value="<?php echo e($key); ?>" <?php echo e($employer->Regency == $key && $employer->Regency ? "selected" :""); ?> ><?php echo e($item); ?></option>
                            <?php endforeach; $__env->popLoop(); $loop = $__env->getLastLoop(); ?>
                        </select>   
                        <?php $__errorArgs = ["Regency"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                        <small class="message"><?php echo e($message); ?></small>
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <!-- end service -->
                    <!-- gender -->
                    <?php
                        $checked=["","",""];
                        $checked[$employer->Gender]="checked";
                    ?>
                    <div class="form-group col-md-4">
                        <label for="">Giới tính: *</label>
                        <div class="custom-control custom-checkbox d-flex">
                            <div class="check-male pr-5">
                                <input type="radio" name="Gender" value="0" <?php echo e($checked[0]); ?> class="custom-control-input" id="male">
                                <label class="custom-control-label" for="male">Nam</label>
                            </div>
                            <div class="check-female">
                                <input type="radio" name="Gender" value="1" <?php echo e($checked[1]); ?> class="custom-control-input" id="female">
                                <label class="custom-control-label" for="female">Nữ</label>
                            </div>
                        </div>
                    </div>
                    <!-- end gender -->
                    <!-- submit -->
                    <div class="form-group col-12">
                        <button class="btn btn-outline-primary">Cập nhật</button>
                    </div>
                    <!-- endsubmit -->
                </form>
            </div>
        </div>
    </div>
</div>

<!-- end model -->
<!-- modal update password -->
<div class="modal fade model-repass" tabindex="-1" role="dialog" aria-hidden="true">
    <div class="modal-dialog modal-dialog-centered modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header p-4">
                <h4 class="mb-0 text-center">Tác vụ</h4>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">&times;</span>
                </button>
            </div>
            <div class="modal-body">
                <form action="<?php echo e(route("employer.changePassword")); ?>" class="row" id="form-update-emplyer" method="post">
                    <?php echo csrf_field(); ?>
                    <input type="hidden" name="continue" value="<?php echo e(route("employer.info")); ?>">
                    <h5 class="title pb-4 col-12">Đổi mật khẩu</h5>
                    <div class="form-group col-md-12 <?php $__errorArgs = ["User_Password_Old"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="User_Password_Old">Mật khẩu cũ: </label>
                        <input type="password" name="User_Password_Old" id="User_Password_Old" class="form-control">
                        <?php $__errorArgs = ["User_Password_Old"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="message"><?php echo e($message); ?></span>    
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group col-md-6 <?php $__errorArgs = ["User_Password_New"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="User_Password_New">Mật khẩu mới: </label>
                        <input type="password" name="User_Password_New" id="User_Password_New" class="form-control">
                        <?php $__errorArgs = ["User_Password_Confirm"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="message"><?php echo e($message); ?></span>    
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group col-md-6 <?php $__errorArgs = ["User_Password_Confirm"];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?> form-error <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>">
                        <label for="User_Password_Confirm">Xác nhận mật khẩu: </label>
                        <input type="password" name="User_Password_Confirm" id="User_Password_Confirm" class="form-control">
                        <?php $__errorArgs = ['User_Password_Confirm'];
$__bag = $errors->getBag($__errorArgs[1] ?? 'default');
if ($__bag->has($__errorArgs[0])) :
if (isset($message)) { $__messageOriginal = $message; }
$message = $__bag->first($__errorArgs[0]); ?>
                            <span class="message"><?php echo e($message); ?></span>    
                        <?php unset($message);
if (isset($__messageOriginal)) { $message = $__messageOriginal; }
endif;
unset($__errorArgs, $__bag); ?>
                    </div>
                    <div class="form-group col-12">
                        <button class="btn btn-outline-primary">Cập nhật</button>
                    </div>
                    <!-- endsubmit -->
                </form>
            </div>
        </div>
    </div>
</div>
<!-- end model -->

<!-- modal upload avatar -->
<div class="modal fade" id="modal-upload-avatar" tabindex="-1" role="dialog" aria-labelledby="modalLabel" aria-hidden="true">
    <div class="modal-dialog modal-lg" role="document">
        <div class="modal-content">
            <div class="modal-header">
                <h5 class="modal-title">Chỉnh sửa avatar</h5>
                <button type="button" class="close" data-dismiss="modal" aria-label="Close">
                    <span aria-hidden="true">×</span>
                </button>
            </div>
            <div class="modal-body">
                <div class="img-container">
                    <div class="row">
                        <div class="col-md-8">
                            <img src="" id="preview_avatar" />
                        </div>
                        <div class="col-md-4">
                            <div class="preview_avatar_mini">
                            </div>
                        </div>
                    </div>
                </div>
            </div>
            <div class="modal-footer">
                <button type="button" id="crop_avatar" class="btn btn-primary">Lưu</button>
            </div>
        </div>
    </div>
</div>
<!-- end modal -->
<?php $__env->stopSection(); ?>
<?php echo $__env->make("employer.master.layout", \Illuminate\Support\Arr::except(get_defined_vars(), ['__data', '__path']))->render(); ?><?php /**PATH C:\xampp\htdocs\laravel\project_cv\jobber\resources\views/employer/user/info.blade.php ENDPATH**/ ?>